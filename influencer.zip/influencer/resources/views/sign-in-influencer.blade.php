<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link
            href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap"
            rel="stylesheet"
        />
        <link rel="stylesheet" href="css/style.min.css" type="text/css" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Influencer platform</title>
    </head>
    <body>
        <main class="login-page__wrapper">
            <div class="login-page__bg-container">
                <img class="login-page__bg-image" src="./image/bg-image.png" />
                <div class="login-page__bg-flex">
                    <h1>Welcome to Influencer Union!</h1>
                </div>
            </div>
            <div class="login-page__container">
                <h2 class="login-page__title">Sign in to your account</h2>
                <form class="login-page__form login-form" method="post" action="{{ route('login') }}">
                    @csrf
                    <label class="login-form__field">
                        <span class="login-form__label">Email</span>
                        <input
                            class="login-form__input"
                            type="email"
                            name="email"
                            value="{{ old('email') }}"
                            placeholder="Enter your email address"
                            required
                        />
                        @error('email')
                        <p class="error-text">{{ $message }}</p>
                        @enderror
                    </label>
                    <label class="login-form__field">
                        <span class="login-form__label">Password</span>
                        <input
                            class="login-form__input"
                            type="password"
                            name="password"
                            placeholder="Enter your password"
                            required
                        />
                    </label>
                    <p class="login-form__description">
                        Forgotten your password? <a href="{{ route('password.request') }}">Click here</a>
                    </p>
                    <div class="login-form__flex-field">
                        <button class="button button--red" type="submit">Sign in</button>
                        <input class="visually-hidden" id="remember-me" name="remember-me" type="checkbox" {{ old('remember') ? 'checked' : '' }} />
                        <label class="checkbox" for="remember-me">Remember me</label>
                    </div>
                    <div class="login-form__flex-field social">
                        <a class="social__link social__link--fb" href="{{url('/redirect')}}"><img src="./image/fb-logo.svg" /></a>
                        <a class="social__link social__link--in" href="{{url('/instagram')}}"><img src="./image/in-logo.svg" /></a>
                    </div>
                    <div class="login-form__flex-field">
                        <p class="login-form__description">
                            Don't have an account yet? <a href="{{url('/register')}}">Sign Up</a>
                        </p>
                    </div>
                </form>
            </div>

            <button class="chat chat__open-button"></button>
        </main>
    </body>
</html>
