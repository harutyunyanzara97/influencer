@extends('influencer.layouts.app')
@section('content')
<!-- --------------------------- top panel start --------------------------- -->
<section class="top-panel">
    <h2 class="visually-hidden">Buttons/search panel</h2>
    <form class="search-form" name="search-form">
        <input class="search-form__input" name="search" placeholder="Search the directory" />
        <button class="search-form__submit" type="submit">GO</button>
    </form>
</section>
<!-- ---------------------------- top panel end ---------------------------- -->

<!-- ------------------------ categories page start ------------------------ -->
<section class="category-page">
    <section class="tab tab__wrapper">
        <h2 class="visually-hidden">Brand, company or Agency search result</h2>
        <h3 class="section__header section__header--search">{{$campaign->count()}} found</h3>
    </section>
</section>

<section style="margin-top: -50px; margin-left: 30px">
    <!-- prettier-ignore -->
    <div class="influencers influencers__wrapper">
        <table class="influencers__table">
            <thead>
            <tr>
                <th class="influencers__col-profile">Brand, company or Agency</th>
                <th class="influencers__col-campaign">Campaign name</th>
                <th class="influencers__col-start-date">Start date</th>
                <th class="influencers__col-budget">Budget</th>
                <th class="influencers__col-goals">Goals</th>
                <th class="influencers__col-details">Details</th>
                <th class="influencers__col-topics">Topics</th>
            </tr>
            </thead>
            <tbody>
            @foreach($campaign as $Campaigns)
            <tr>
                <td class="influencers__row-profile">
                    <div class="influencers__row-flex">
                        <button class="influencers__row-name button-open-influencer-info" href="#" >
                            <img class="avatar__image" src="https://images.unsplash.com/photo-1611176346948-a19de4f62140?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80" width="50" height="50">
                            Patagonia</button>
                        <a class="influencers__row-message" href="message"></a>
                        <a class="influencers__row-bookmark influencers__row-bookmark--checked" href="bookmark"></a>
                        <a class="influencers__row-note" href="note"></a>
                        <a class="influencers__row-more" href="three-dots"></a>
                    </div>
                </td>
                <td class="influencers__row-campaign">
                    {{ $Campaigns->title }}
                </td>
                <td class="influencers__row-start-date">
                    {{ date('Y-m-d', strtotime($Campaigns->start_date)) }}
                </td>
                <td class="influencers__row-budget">
                    $1000
                </td>
                <td class="influencers__row-goals">
                    -
                </td>
                <td class="influencers__row-details">
                    -
                </td>
                <td class="influencers__row-topics">
                    <ul class="topic topic__list">
                        @foreach(explode(",", $Campaigns->hashtags) as $topic)
                            <li class="topic__element topic__element--{{$topic}}">{{$topic}}</li>
                        @endforeach
                    </ul>
                </td>
            </tr>
            @endforeach
            </tbody>
            <tfoot></tfoot>
        </table>
    </div>
</section>
<!-- ------------------------- categories page end ------------------------- -->
{{--</div>--}}
<!-- -------------------------- main content end -------------------------- -->
<button class="chat chat__open-button"></button>
@endsection
