<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link
            href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap"
            rel="stylesheet"
        />
        <link rel="stylesheet" href="css/style.min.css" type="text/css" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Influencer platform</title>
    </head>
    <body>
        <main class="container">
            <h1 class="visually-hidden">Influencer Union</h1>
            @include('influencer/layouts.side-nav')
            <div class="main-content">
                @yield('content')
            </div>
        </main>
            <script src="scripts/script.min.js"></script>
    </body>
</html>
