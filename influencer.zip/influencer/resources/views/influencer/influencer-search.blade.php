@extends('influencer.layouts.app')
@section('content')
    <!-- --------------------------- top panel start --------------------------- -->
    <section class="top-panel">
        <h2 class="visually-hidden">Buttons/search panel</h2>
        <form class="search-form" name="search-form" action="/searchCampaign" method="get" >
            <input class="search-form__input" name="search" placeholder=" {{ $message ?? 'Search the directory'}}" />
            <button class="search-form__submit" type="submit">GO</button>
        </form>
    </section>
    <!-- ---------------------------- top panel end ---------------------------- -->



    <!-- ------------------------ categories page start ------------------------ -->
    <section class="category-page">
        <section class="tab tab__wrapper">
            <h2 class="visually-hidden">Search page</h2>
            <h3 class="section__header">Find campaign in these topics</h3>
            <ul class="category-page__list">
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'fashion']) }}">
                        <img
                            src="./image/inf1.png"
                            width="210"
                            height="197"
                            alt="Fashion category image"
                        />
                        <span>Fashion</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'beauty']) }}">
                        <img
                            src="./image/inf2.png"
                            width="210"
                            height="197"
                            alt="Beauty category image"
                        />
                        <span>Beauty</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'travel']) }}">
                        <img
                            src="./image/inf3.png"
                            width="210"
                            height="197"
                            alt="Travel category image"
                        />
                        <span>Travel</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'animal & pets']) }}">
                        <img
                            src="./image/inf4.png"
                            width="210"
                            height="197"
                            alt="Animals & pets category image"
                        />
                        <span>Animals & pets</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'health & fitness']) }}">
                        <img
                            src="./image/inf5.png"
                            width="210"
                            height="197"
                            alt="Health & fitness category image"
                        />
                        <span>Health & fitness</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'food & drink']) }}">
                        <img
                            src="./image/inf6.png"
                            width="210"
                            height="197"
                            alt="Food & drink category image"
                        />
                        <span class="">Food & drink</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'wedding']) }}">
                        <img
                            src="./image/inf7.png"
                            width="210"
                            height="197"
                            alt="Wedding category image"
                        />
                        <span>Wedding</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'home interior']) }}">
                        <img
                            src="./image/inf8.png"
                            width="210"
                            height="197"
                            alt="Home interior category image"
                        />
                        <span>Home interior</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'business & finance']) }}">
                        <img
                            src="./image/inf9.png"
                            width="210"
                            height="197"
                            alt="Business & finance category image"
                        />
                        <span>Business & finance</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'baking']) }}">
                        <img
                            src="./image/inf10.png"
                            width="210"
                            height="197"
                            alt="Baking category image"
                        />
                        <span>Baking</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'sport']) }}">
                        <img
                            src="./image/inf11.png"
                            width="210"
                            height="197"
                            alt="Sport category image"
                        />
                        <span>Sport</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'technology']) }}">
                        <img
                            src="./image/inf12.png"
                            width="210"
                            height="197"
                            alt="Technology category image"
                        />
                        <span>Technology</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'fashion']) }}">
                        <img
                            src="./image/inf13.png"
                            width="210"
                            height="197"
                            alt="Fashion category image"
                        />
                        <span>Fashion</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'fashion']) }}">
                        <img
                            src="./image/inf14.png"
                            width="210"
                            height="197"
                            alt="Fashion category image"
                        />
                        <span>Fashion</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'fashion']) }}">
                        <img
                            src="./image/inf15.png"
                            width="210"
                            height="197"
                            alt="Fashion category image"
                        />
                        <span>Fashion</span>
                    </a>
                </li>
                <li class="category-page__element">
                    <a class="category-page__link" href="{{ route('search', ['search' => 'fashion']) }}">
                        <img
                            src="./image/inf16.png"
                            width="210"
                            height="197"
                            alt="Fashion category image"
                        />
                        <span>Fashion</span>
                    </a>
                </li>
            </ul>
        </section>
    </section>
    <!-- ------------------------- categories page end ------------------------- -->
{{--    </div>--}}
    <!-- -------------------------- main content end -------------------------- -->

    <button class="chat chat__open-button"></button>
@endsection
