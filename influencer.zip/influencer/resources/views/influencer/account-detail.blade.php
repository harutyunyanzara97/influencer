<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap"
        rel="stylesheet"
    />
    <link rel="stylesheet" href="css/style.min.css" type="text/css" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Influencer platform</title>
</head>
<body>
<main class="account-info-page">
    <div class="account-info-page__wrapper">
        <h1 class="account-info-page__title">Welcome to Influencer Union</h1>
        <p class="account-info-page__description">
            Please fill out the requested information within next few screens in order to finalize
            setting up your account
        </p>
        <form action="/home" method="post">
            @csrf
            <div class="account-info-progress">
                <h2 class="account-info-progress__title">Finalizing your account</h2>
                <div class="account-info-progress__list">
                    <span class="account-info-progress__element">Credit Card Information</span>
                    <span class="account-info-progress__element">Select Categories</span>
                    <span class="account-info-progress__element">Select Network</span>
                    <span class="account-info-progress__element">Create Rate Card</span>
                </div>
            </div>
            <!-- ---------------------- start of Payment section ----------------------- -->
            <section id="payment-section">
                <div class="account-section">
                    <h3 class="account-section__title">
                        Payment Method ... <span>How Would You Like To Be Paid?</span>
                    </h3>
                    <div class="info-block">
                        <div>
                            <div class="info-block__custom-select custom-select">
                                <select id="payment-method">
                                    <option value="0">Choose a payment method</option>
                                    <option value="1">Credit Card</option>
                                    <option value="2">Paypal account</option>
                                    <option value="3">
                                        E-transfer <span>(with automatic deposit only)</span>
                                    </option>
                                    <option value="4">Wire Transfer</option>
                                </select>
                            </div>
                            <p class="info-block__2st-line">
                                Please have the required payment method information ready, then select the Add
                                button
                            </p>
                        </div>
                        <button class="button button--red" id="button-open-card" type="button">Add</button>
                        <button
                            class="button button--transparent-red"
                            id="button-delete-card"
                            type="button"
                        >
                            Delete
                        </button>
                        <button
                            class="button button--red"
                            id="button-open-paypal"
                            type="button"
                            style="display: none"
                        >
                            Add
                        </button>
                        <button
                            class="button button--red"
                            id="button-open-e-transfer"
                            type="button"
                            style="display: none"
                        >
                            Add
                        </button>
                        <button
                            class="button button--red"
                            id="button-open-wire"
                            type="button"
                            style="display: none"
                        >
                            Add
                        </button>
                    </div>
                </div>

                <div class="account-section">
                    <h3 class="account-section__title">Billing Address</h3>

                    <div class="info-block form__vertical-flex">
                        <div class="form__icon-wrapper form__icon-wrapper--name">
                            <input
                                class="form__input form__field form__field--name"
                                id="billing-account-name"
                                type="text"
                                name="fullname"
                                value="{{ Auth::check() ? auth()->user()->name. " ". auth()->user()->last_name : ""}}"
                                placeholder="Full Name"
                            />
                        </div>
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-address-1"
                            type="text"
                            placeholder="Address 1"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-address-2"
                            type="text"
                            placeholder="Address 2"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-city"
                            type="text"
                            placeholder="City"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-state"
                            type="text"
                            placeholder="State"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-country"
                            type="text"
                            placeholder="Country"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-zip-code"
                            type="text"
                            placeholder="Zip Code"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-iban"
                            type="text"
                            value="{{ Auth::check() ? auth()->user()->phone : ""}}"
                            placeholder="Phone Number"
                        />
                    </div>
                </div>

                <div class="account-section">
                    <h3 class="account-section__title">Billing email address</h3>
                    <div>
                        <div class="info-block">
                            <div>
                                <p class="info-block__1st-line">
                                    Billing email: <span id="billing-email">{{ Auth::check() ? auth()->user()->email : ""}}</span>
                                </p>
                                <p class="info-block__2st-line">
                                    Press the update button if you wish to use a different email address for
                                    billing
                                </p>
                            </div>
                            <button
                                class="button button--red"
                                id="button-open-billing-email-modal"
                                type="button"
                            >
                                Update
                            </button>
                        </div>
                    </div>
                </div>
                <div class="account-section__button-wrapper">
                    <button class="button button--red" id="payment-next-button" type="button">
                        Next
                    </button>
                </div>

                <!-- ------------------------ modal card start ------------------------- -->
                <div class="modal" id="modal-card">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-card-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Credit Card Information</h3>
                        <p class="modal__description modal__description--card">loremipsum@gmail.com</p>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--name">
                                <input
                                    class="form__input form__field form__field--name"
                                    id="card-name"
                                    type="text"
                                    placeholder="Name on Card"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--number">
                                <input
                                    class="form__input form__field form__field--number"
                                    id="card-number"
                                    type="text"
                                    placeholder="Card number"
                                    maxlength="16"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--mm">
                                <input
                                    class="form__input form__field form__field--mm"
                                    id="card-mm"
                                    type="text"
                                    placeholder="MM"
                                    maxlength="2"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--yyyy">
                                <input
                                    class="form__input form__field form__field--yyyy"
                                    id="card-yyyy"
                                    type="text"
                                    placeholder="YYYYY"
                                    maxlength="4"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--cvc">
                                <input
                                    class="form__input form__field form__field--cvc"
                                    id="card-cvc"
                                    type="text"
                                    placeholder="CVC"
                                    maxlength="3"
                                />
                            </div>
                            <button
                                class="button button--red button--long button--45"
                                id="modal-card-add-button"
                                type="button"
                            >
                                Add Credit Card
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal card end ------------------------- -->

                <!-- ------------------------ modal paypal start ------------------------- -->
                <div class="modal" id="modal-paypal">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-paypal-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Paypal Account Information</h3>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--name">
                                <input
                                    class="form__input form__field form__field--name"
                                    id="paypal-name"
                                    type="text"
                                    placeholder="Name of Paypal account"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--email">
                                <input
                                    class="form__input form__field form__field--email"
                                    id="paypal-email"
                                    type="text"
                                    placeholder="Email address of Paypal account"
                                />
                            </div>
                            <button
                                class="button button--red button--long button--45"
                                id="modal-paypal-add-button"
                                type="button"
                            >
                                Add Paypal Account
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal paypal end ------------------------- -->
                <!-- ------------------------ modal e-transfer start ------------------------- -->
                <div class="modal" id="modal-e-transfer">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-e-transfer-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">E-Transfer Account Information</h3>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--name">
                                <input
                                    class="form__input form__field form__field--name"
                                    id="e-transfer-name"
                                    type="text"
                                    placeholder="Name of E-Transfer account"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--email">
                                <input
                                    class="form__input form__field form__field--email"
                                    id="e-transfer-email"
                                    type="text"
                                    placeholder="Email address of E-Transfer account"
                                />
                            </div>
                            <button
                                class="button button--red button--long button--45"
                                id="modal-e-transfer-add-button"
                                type="button"
                            >
                                Add E-Transfer Account
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal e-transfer end ------------------------- -->
                <!-- ------------------------ modal wire start ------------------------- -->
                <div class="modal" id="modal-wire">
                    <div class="modal__popup-wire">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-wire-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Wire Transfer Information</h3>

                        <div class="modal__field-wrapper">
                            <div class="modal__vertical-wrapper">
                                <div class="form__icon-wrapper form__icon-wrapper--name">
                                    <input
                                        class="form__input form__field form__field--name"
                                        id="wire-account-name"
                                        type="text"
                                        placeholder="Full Name of the account"
                                    />
                                </div>
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-address-1"
                                    type="text"
                                    placeholder="Address 1"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-address-2"
                                    type="text"
                                    placeholder="Address 2"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-city"
                                    type="text"
                                    placeholder="City"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-state"
                                    type="text"
                                    placeholder="State"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-country"
                                    type="text"
                                    placeholder="Country"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-zip-code"
                                    type="text"
                                    placeholder="Zip Code"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-iban"
                                    type="text"
                                    placeholder="Account number or IBAN"
                                />
                                <div class="form__flex-field form__field--w100">
                                    <input
                                        class="visually-hidden"
                                        id="wire-checking-account"
                                        name="wire-checking-account"
                                        type="checkbox"
                                    />
                                    <label class="checkbox" for="wire-checking-account">Checking account</label>
                                    <input
                                        class="visually-hidden"
                                        id="wire-saving-account"
                                        name="wire-saving-account"
                                        type="checkbox"
                                    />
                                    <label class="checkbox" for="wire-saving-account">Saving account</label>
                                </div>
                            </div>

                            <div class="modal__vertical-wrapper">
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-account-name"
                                    type="text"
                                    placeholder="Bank Name"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-address-1"
                                    type="text"
                                    placeholder="Address 1"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-address-2"
                                    type="text"
                                    placeholder="Address 2"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-city"
                                    type="text"
                                    placeholder="City"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-state"
                                    type="text"
                                    placeholder="State"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-country"
                                    type="text"
                                    placeholder="country"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-zip-code"
                                    type="text"
                                    placeholder="Zip Code"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-routing-number"
                                    type="text"
                                    placeholder="Bank Routing number"
                                />
                                <div class="form__field form__field--small">
                                    <strong>Note</strong>: $45 wire transfer fee applies for every transaction
                                </div>
                            </div>

                            <button
                                class="button button--red button--45 modal__centered-button"
                                id="modal-wire-add-button"
                                type="button"
                            >
                                Add Wire Transfer
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal wire end ------------------------- -->
                <!-- ------------------------ modal billing email start ------------------------- -->
                <div class="modal" id="modal-billing-email">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-billing-email-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Billing Email</h3>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--email">
                                <input
                                    class="form__input form__field form__field--email"
                                    id="billing-email-address"
                                    type="text"
                                    placeholder="Billing email"
                                />
                            </div>

                            <button
                                class="button button--red button--long button--45"
                                id="modal-billing-email-add-button"
                                type="button"
                            >
                                Update Email Address
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal e-transfer end ------------------------- -->
            </section>
            <!-- ----------------------- end of Payment section ------------------------ -->
            <!-- --------------------- start of Categories section --------------------- -->
            <section id="categories-section">
                <div class="account-section">
                    <h3 class="account-section__title">Select Categories</h3>

                    <div class="info-block">
                        <!-- <div class="account-section__wrapper account-section__wrapper--categories"> -->
                        <!-- prettier-ignore -->
                        <ul class="categories categories__list">
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="fashion" name="fashion" type="checkbox" />
                                <label class="checkbox" for="fashion">Fashion</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="wedding" name="wedding" type="checkbox" />
                                <label class="checkbox" for="wedding">Wedding</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="books" name="books" type="checkbox" />
                                <label class="checkbox" for="books">Books</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="beauty" name="beauty" type="checkbox" />
                                <label class="checkbox" for="beauty">Beauty</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="home-interior" name="home-interior" type="checkbox" />
                                <label class="checkbox" for="home-interior">Home interior</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="environment" name="environment" type="checkbox" />
                                <label class="checkbox" for="environment">Environment</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="travel" name="travel" type="checkbox" />
                                <label class="checkbox" for="travel">Travel</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="business-n-finance" name="business-n-finance" type="checkbox" />
                                <label class="checkbox" for="business-n-finance">Business & finance</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="family" name="family" type="checkbox" />
                                <label class="checkbox" for="family">Family</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="animals-n-pets" name="animals-n-pets" type="checkbox" />
                                <label class="checkbox" for="animals-n-pets">Animals & pets</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="baking" name="baking" type="checkbox" />
                                <label class="checkbox" for="baking">Baking</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="music" name="music" type="checkbox" />
                                <label class="checkbox" for="music">Music</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="health-n-fitness" name="health-n-fitness" type="checkbox" />
                                <label class="checkbox" for="health-n-fitness">Health & fitness</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="sport" name="sport" type="checkbox" />
                                <label class="checkbox" for="sport">Sport</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="organic-food" name="organic-food" type="checkbox" />
                                <label class="checkbox" for="organic-food">Organic food</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="food-n-drink" name="food-n-drink" type="checkbox" />
                                <label class="checkbox" for="food-n-drink">Food & drink</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="technology" name="technology" type="checkbox" />
                                <label class="checkbox" for="technology">Technology</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="photography" name="photography" type="checkbox" />
                                <label class="checkbox" for="photography">Photography</label>
                            </li>
                            <li class="categories__element categories__element--4column">
                                <input class="visually-hidden" id="sustainability" name="sustainability" type="checkbox" />
                                <label class="checkbox" for="sustainability">Sustainability</label>
                            </li>
                        </ul>
                    </div>
                    <p class="account-section__description">Please select at least one category</p>
                </div>
                <div class="form__flex-field">
                    <button
                        class="button button--transparent-red"
                        id="categories-prev-button"
                        type="button"
                    >
                        Preview
                    </button>
                    <button class="button button--red" id="categories-next-button" type="button">
                        Next
                    </button>
                </div>
            </section>
            <!-- ---------------------- end of Categories section ---------------------- -->
            <!-- ---------------------- start of Network section ----------------------- -->
            <section id="network-section">
                <div class="account-section">
                    <h3 class="account-section__title">Network Selection</h3>
                    <div class="info-block">
                        <!-- prettier-ignore -->
                        <ul class="form__field-list form__field-list--2column">
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">Facebook</span>
                                    <input class="form__input" type="text" name="fb-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-fb-link-on" name="is-fb-link-on" type="checkbox"/>
                                    <label class="on-off" for="is-fb-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">Twitter</span>
                                    <input class="form__input" type="text" name="tw-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-tw-link-on" name="is-tw-link-on" type="checkbox" />
                                    <label class="on-off" for="is-tw-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">LinkedIn</span>
                                    <input class="form__input" type="text" name="ln-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-ln-link-on" name="is-ln-link-on" type="checkbox" />
                                    <label class="on-off" for="is-ln-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">Tumblr</span>
                                    <input class="form__input" type="text" name="tm-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-tm-link-on" name="is-tm-link-on" type="checkbox" />
                                    <label class="on-off" for="is-tm-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">YouTube</span>
                                    <input class="form__input" type="text" name="yo-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-yo-link-on" name="is-yo-link-on" type="checkbox" />
                                    <label class="on-off" for="is-yo-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">Patreon</span>
                                    <input class="form__input" type="text" name="pt-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-pt-link-on" name="is-pt-link-on" type="checkbox" />
                                    <label class="on-off" for="is-pt-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">Pinterest</span>
                                    <input class="form__input" type="text" name="pn-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-pn-link-on" name="is-pn-link-on" type="checkbox" />
                                    <label class="on-off" for="is-pn-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">Website</span>
                                    <input class="form__input" type="text" name="ws-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-ws-link-on" name="is-ws-link-on" type="checkbox" />
                                    <label class="on-off" for="is-ws-link-on"></label>
                                </label>
                            </li>
                            <li>
                                <label class="form__vertical-field">
                                    <span class="form__label">Instagram</span>
                                    <input class="form__input" type="text" name="in-link" placeholder="https://" />

                                    <input class="visually-hidden" id="is-in-link-on" name="is-in-link-on" type="checkbox" />
                                    <label class="on-off" for="is-in-link-on"></label>
                                </label>
                            </li>
                        </ul>
                    </div>
                    <p class="account-section__description">Please select at least one Network</p>
                </div>
                <div class="form__flex-field">
                    <button class="button button--transparent-red" id="network-prev-button" type="button">
                        Preview
                    </button>
                    <button class="button button--red" id="network-next-button" type="button">
                        Next
                    </button>
                </div>
            </section>
            <!-- ----------------------- end of Network section ------------------------ -->
            <!-- ---------------------- start of Rate Card section ----------------------- -->
            <section id="rate-card-section">
                <div class="account-section">
                    <h3 class="account-section__title">Network Selection</h3>
                    <div class="info-block">
                        <p class="info-block__remark">Enter rate in US dollars</p>
                        <!-- prettier-ignore -->
                        <ul class="form__field-list">
                            <li class="form__flex-130">
                                <label class="form__vertical-field">
                                    <span class="form__label">Facebook Post</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                                <label class="form__vertical-field">
                                    <span class="form__label">Facebook Story</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                            </li>
                            <li class="form__flex-130">
                                <label class="form__vertical-field">
                                    <span class="form__label">YouTube Video</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                            </li>
                            <li class="form__flex-130">
                                <label class="form__vertical-field">
                                    <span class="form__label">Instagram Post</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                                <label class="form__vertical-field">
                                    <span class="form__label">Instagram Story</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                                <label class="form__vertical-field">
                                    <span class="form__label">Instagram Video</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                            </li>
                            <li class="form__flex-130">
                                <label class="form__vertical-field">
                                    <span class="form__label">Twitter Post</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                            </li>
                            <li class="form__flex-130">
                                <label class="form__vertical-field">
                                    <span class="form__label">Pinterest Post</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                            </li>
                            <li class="form__flex-130">
                                <label class="form__vertical-field">
                                    <span class="form__label">LinkedIn Post</span>
                                    <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                                </label>
                            </li>
                        </ul>
                    </div>
                    <p class="account-section__description">
                        Please create a rate card for the chosen network
                    </p>
                </div>
                <div class="form__flex-field">
                    <button
                        class="button button--transparent-red"
                        id="rate-card-prev-button"
                        type="button"
                    >
                        Preview
                    </button>
                    <button class="button button--red" type="submit">Done</button>
                </div>
            </section>
            <!-- ----------------------- end of Rate Card section ------------------------ -->
        </form>
    </div>

    <button class="chat chat__open-button"></button>
</main>
<script src="scripts/sign-up.min.js"></script>
</body>
</html>
