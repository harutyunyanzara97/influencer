@extends('influencer.layouts.app')
@section('content')
    <!-- -------------------------- blank page start --------------------------- -->
    <section class="blank-page">
        <h2 class="visually-hidden">Blank page</h2>
        <img src="/image/image.png" width="138" height="138" alt="applause" />
        <p>Welcome to Influencer Union</p>
    </section>
    <!-- --------------------------- blank page end ---------------------------- -->
@endsection
