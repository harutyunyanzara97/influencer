@extends('influencer.layouts.app')
@section('content')
    <!-- --------------------------- top panel start --------------------------- -->
    <section class="top-panel">
        <h2 class="top-panel__account-profile">Billing Details</h2>
    </section>
    <!-- ---------------------------- top panel end ---------------------------- -->

    <!-- ------------------------- billing page start -------------------------- -->
    <section class="profile-page">
        <section class="tab tab__wrapper" id="tab-profile">
            <!-- ---------------------- start of Payment section ----------------------- -->
            <section id="payment-section">
                <div class="account-section">
                    <h3 class="account-section__title">
                        Payment Method ... <span>How Would You Like To Be Paid?</span>
                    </h3>
                    <div class="info-block">
                        <div>
                            <div class="info-block__custom-select custom-select">
                                <select id="payment-method">
                                    <option value="0">Choose a payment method</option>
                                    <option value="1">Credit Card</option>
                                    <option value="2">Paypal account</option>
                                    <option value="3">E-transfer (with automatic deposit only)</span></option>
                                    <option value="4">Wire Transfer</option>
                                </select>
                            </div>
                            <p class="info-block__2st-line">
                                Please have the required payment method information ready, then select the Add
                                button
                            </p>
                        </div>
                        <button class="button button--red" id="button-open-card" type="button">
                            Add
                        </button>
                        <button
                            class="button button--transparent-red"
                            id="button-delete-card"
                            type="button"
                        >
                            Delete
                        </button>
                        <button
                            class="button button--red"
                            id="button-open-paypal"
                            type="button"
                            style="display: none"
                        >
                            Add
                        </button>
                        <button
                            class="button button--red"
                            id="button-open-e-transfer"
                            type="button"
                            style="display: none"
                        >
                            Add
                        </button>
                        <button
                            class="button button--red"
                            id="button-open-wire"
                            type="button"
                            style="display: none"
                        >
                            Add
                        </button>
                    </div>
                </div>

                <div class="account-section">
                    <div>
                        <div class="info-block">
                            <div>
                                <p class="info-block__1st-line">
                                    Billing email: <span id="billing-email">lorem@gmail.com</span>
                                </p>
                                <p class="info-block__2st-line">
                                    Press the update button if you wish to use a different email address for
                                    billing
                                </p>
                            </div>
                            <button
                                class="button button--red"
                                id="button-open-billing-email-modal"
                                type="button"
                            >
                                Update
                            </button>
                        </div>
                    </div>
                </div>

                <div class="account-section">
                    <h3 class="account-section__title">Billing Address</h3>

                    <div class="info-block form__vertical-flex">
                        <div class="form__icon-wrapper form__icon-wrapper--name">
                            <input
                                class="form__input form__field form__field--name"
                                id="billing-account-name"
                                type="text"
                                placeholder="Full Name"
                            />
                        </div>
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-address-1"
                            type="text"
                            placeholder="Address 1"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-address-2"
                            type="text"
                            placeholder="Address 2"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-city"
                            type="text"
                            placeholder="City"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-state"
                            type="text"
                            placeholder="State"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-country"
                            type="text"
                            placeholder="Country"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-zip-code"
                            type="text"
                            placeholder="Zip Code"
                        />
                        <input
                            class="form__input form__field form__field--w100"
                            id="billing-iban"
                            type="text"
                            placeholder="Phone Number"
                        />
                    </div>
                </div>

                <!-- ------------------------ modal card start ------------------------- -->
                <div class="modal" id="modal-card">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-card-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Credit Card Information</h3>
                        <p class="modal__description modal__description--card">loremipsum@gmail.com</p>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--name">
                                <input
                                    class="form__input form__field form__field--name"
                                    id="card-name"
                                    type="text"
                                    placeholder="Name on Card"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--number">
                                <input
                                    class="form__input form__field form__field--number"
                                    id="card-number"
                                    type="text"
                                    placeholder="Card number"
                                    maxlength="16"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--mm">
                                <input
                                    class="form__input form__field form__field--mm"
                                    id="card-mm"
                                    type="text"
                                    placeholder="MM"
                                    maxlength="2"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--yyyy">
                                <input
                                    class="form__input form__field form__field--yyyy"
                                    id="card-yyyy"
                                    type="text"
                                    placeholder="YYYYY"
                                    maxlength="4"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--cvc">
                                <input
                                    class="form__input form__field form__field--cvc"
                                    id="card-cvc"
                                    type="text"
                                    placeholder="CVC"
                                    maxlength="3"
                                />
                            </div>
                            <button
                                class="button button--red button--long button--45"
                                id="modal-card-add-button"
                                type="button"
                            >
                                Add Credit Card
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal card end ------------------------- -->

                <!-- ------------------------ modal paypal start ------------------------- -->
                <div class="modal" id="modal-paypal">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-paypal-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Paypal Account Information</h3>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--name">
                                <input
                                    class="form__input form__field form__field--name"
                                    id="paypal-name"
                                    type="text"
                                    placeholder="Name of Paypal account"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--email">
                                <input
                                    class="form__input form__field form__field--email"
                                    id="paypal-email"
                                    type="text"
                                    placeholder="Email address of Paypal account"
                                />
                            </div>
                            <button
                                class="button button--red button--long button--45"
                                id="modal-paypal-add-button"
                                type="button"
                            >
                                Add Paypal Account
                            </button>
                        </div>
                    </div>
                </div>
                <!-- -------------------------- modal paypal end --------------------------- -->
                <!-- ----------------------- modal e-transfer start ------------------------ -->
                <div class="modal" id="modal-e-transfer">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-e-transfer-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">E-Transfer Account Information</h3>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--name">
                                <input
                                    class="form__input form__field form__field--name"
                                    id="e-transfer-name"
                                    type="text"
                                    placeholder="Name of E-Transfer account"
                                />
                            </div>
                            <div class="form__icon-wrapper form__icon-wrapper--email">
                                <input
                                    class="form__input form__field form__field--email"
                                    id="e-transfer-email"
                                    type="text"
                                    placeholder="Email address of E-Transfer account"
                                />
                            </div>
                            <button
                                class="button button--red button--long button--45"
                                id="modal-e-transfer-add-button"
                                type="button"
                            >
                                Add E-Transfer Account
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal e-transfer end ------------------------- -->
                <!-- -------------------------- modal wire start --------------------------- -->
                <div class="modal" id="modal-wire">
                    <div class="modal__popup-wire">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-wire-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Wire Transfer Information</h3>

                        <div class="modal__field-wrapper">
                            <div class="modal__vertical-wrapper">
                                <div class="form__icon-wrapper form__icon-wrapper--name">
                                    <input
                                        class="form__input form__field form__field--name"
                                        id="wire-account-name"
                                        type="text"
                                        placeholder="Full Name of the account"
                                    />
                                </div>
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-address-1"
                                    type="text"
                                    placeholder="Address 1"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-address-2"
                                    type="text"
                                    placeholder="Address 2"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-city"
                                    type="text"
                                    placeholder="City"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-state"
                                    type="text"
                                    placeholder="State"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-country"
                                    type="text"
                                    placeholder="Country"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-zip-code"
                                    type="text"
                                    placeholder="Zip Code"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-iban"
                                    type="text"
                                    placeholder="Account number or IBAN"
                                />
                                <div class="form__flex-field form__field--w100">
                                    <input
                                        class="visually-hidden"
                                        id="wire-checking-account"
                                        name="wire-checking-account"
                                        type="checkbox"
                                    />
                                    <label class="checkbox" for="wire-checking-account">Checking account</label>
                                    <input
                                        class="visually-hidden"
                                        id="wire-saving-account"
                                        name="wire-saving-account"
                                        type="checkbox"
                                    />
                                    <label class="checkbox" for="wire-saving-account">Saving account</label>
                                </div>
                            </div>

                            <div class="modal__vertical-wrapper">
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-account-name"
                                    type="text"
                                    placeholder="Bank Name"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-address-1"
                                    type="text"
                                    placeholder="Address 1"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-address-2"
                                    type="text"
                                    placeholder="Address 2"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-city"
                                    type="text"
                                    placeholder="City"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-state"
                                    type="text"
                                    placeholder="State"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-country"
                                    type="text"
                                    placeholder="country"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-zip-code"
                                    type="text"
                                    placeholder="Zip Code"
                                />
                                <input
                                    class="form__input form__field form__field--w100"
                                    id="wire-bank-routing-number"
                                    type="text"
                                    placeholder="Bank Routing number"
                                />
                                <div class="form__field form__field--small">
                                    <strong>Note</strong>: $45 wire transfer fee applies for every transaction
                                </div>
                            </div>

                            <button
                                class="button button--red button--45 modal__centered-button"
                                id="modal-wire-add-button"
                                type="button"
                            >
                                Add Wire Transfer
                            </button>
                        </div>
                    </div>
                </div>
                <!-- --------------------------- modal wire end ---------------------------- -->
                <!-- ---------------------- modal billing email start ---------------------- -->
                <div class="modal" id="modal-billing-email">
                    <div class="modal__popup-card">
                        <div class="modal__header">
                            <button
                                class="modal__close-button"
                                id="modal-billing-email-close-button"
                                type="button"
                            ></button>
                        </div>

                        <h3 class="modal__title modal__title--card">Billing Email</h3>

                        <div class="modal__field-wrapper">
                            <div class="form__icon-wrapper form__icon-wrapper--email">
                                <input
                                    class="form__input form__field form__field--email"
                                    id="billing-email-address"
                                    type="text"
                                    placeholder="Billing email"
                                />
                            </div>

                            <button
                                class="button button--red button--long button--45"
                                id="modal-billing-email-add-button"
                                type="button"
                            >
                                Update Email Address
                            </button>
                        </div>
                    </div>
                </div>
                <!-- ------------------------ modal e-transfer end ------------------------- -->
            </section>
            <!-- ----------------------- end of Payment section ------------------------ -->
        </section>
    </section>
    <!-- -------------------------- billing page end --------------------------- -->
    <button class="chat chat__open-button"></button>
@endsection
