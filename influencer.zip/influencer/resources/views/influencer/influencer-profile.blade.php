@extends('influencer.layouts.app')
@section('content')
    <!-- --------------------------- top panel start --------------------------- -->
    <section class="top-panel">
        <h2 class="top-panel__account-profile">Account profile/{{ Auth::check() ? auth()->user()->name. " ". auth()->user()->last_name : "Guest User"}}</h2>
    </section>
    <!-- ---------------------------- top panel end ---------------------------- -->
    <!-- ------------------------- profile page start -------------------------- -->
    <section class="profile-page">
        <section class="tab tab__wrapper" id="tab-profile">
            <!-- ------------------------ Account profile start ------------------------ -->
            <h2 class="tab__title">
                Account profile<span class="tab__description">Account creation Date {{ auth()->user()->created_at->format('yy-m-d') }}</span>
            </h2>

            <div class="info-block">
                <form class="profile-page__form form">
                    <div class="avatar avatar--modal profile-page__form-avatar">
                        <img
                            class="avatar__image"
                            id="avatar-preview"
                            @if(!auth()->user()->avatar_url){src="img/avatar.svg" } @else { src="img/{{ auth()->user()->avatar_url}}" } @endif
                            width="75"
                            height="75"
                        />

                        <label class="avatar__button">
                            <input
                                type="file"
                                id="avatar"
                                class="visually-hidden"
                                accept="image/png, image/jpeg"
                            />
                        </label>
                    </div>

                    <label class="form__vertical-field">
                        <span class="form__label">First Name *</span>
                        <input
                            class="form__input"
                            type="text"
                            name="influencer-first-name"
                            value="{{ auth()->user() ? auth()->user()->name : ""}}"
                            placeholder="Enter your first name"
                            required
                        />
                    </label>

                    <label class="form__vertical-field">
                        <span class="form__label">Last Name *</span>
                        <input
                            class="form__input"
                            type="text"
                            name="influencer-last-name"
                            value="{{ auth()->user() ? auth()->user()->last_name : ""}}"
                            placeholder="Enter your last name"
                            required
                        />
                    </label>

                    <label class="form__vertical-field">
                        <span class="form__label">Company name</span>
                        <input
                            class="form__input"
                            type="text"
                            name="influencer-company"
                            value="{{ auth()->user() ? auth()->user()->company_name : ""}}"
                            placeholder="Enter your company name"
                        />
                    </label>

                    <label class="form__vertical-field">
                        <span class="form__label">Email *</span>
                        <input
                            class="form__input"
                            type="email"
                            name="influencer-email"
                            value="{{ auth()->user() ? auth()->user()->email : ""}}"
                            placeholder="Enter your email"
                            required
                        />
                    </label>
                    <input
                        class="visually-hidden"
                        id="billing-email-flag"
                        name="billing-email-flag"
                        type="checkbox"
                    />
                    <label class="checkbox profile-page__checkbox" for="billing-email-flag"
                    >Change also apply to my billing email address</label
                    >

                    <div class="form__flex-field profile-page__ok-cancel">
                        <button class="button button--transparent-red" type="button">Cancel</button>
                        <button class="button button--red" type="submit">Save</button>
                    </div>
                </form>
            </div>
            <div class="tab__button-wrapper">
                <span class="tab__button">Edit info</span>|<span class="tab__button"
                >edit Profile</span
                >
            </div>
            <!-- ------------------------- Account profile end ------------------------- -->

            <!-- ------------------------ Select category start ------------------------ -->
            <h2 class="tab__title">Select Category</h2>

            <div class="info-block">
                <form class="profile-page__form form">
                    <!-- prettier-ignore -->
                    <ul class="categories categories__list">
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="fashion" name="fashion" type="checkbox" />
                            <label class="checkbox" for="fashion">Fashion</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="wedding" name="wedding" type="checkbox" />
                            <label class="checkbox" for="wedding">Wedding</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="books" name="books" type="checkbox" />
                            <label class="checkbox" for="books">Books</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="beauty" name="beauty" type="checkbox" />
                            <label class="checkbox" for="beauty">Beauty</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="home-interior" name="home-interior" type="checkbox" />
                            <label class="checkbox" for="home-interior">Home interior</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="environment" name="environment" type="checkbox" />
                            <label class="checkbox" for="environment">Environment</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="travel" name="travel" type="checkbox" />
                            <label class="checkbox" for="travel">Travel</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="business-n-finance" name="business-n-finance" type="checkbox" />
                            <label class="checkbox" for="business-n-finance">Business & finance</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="family" name="family" type="checkbox" />
                            <label class="checkbox" for="family">Family</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="animals-n-pets" name="animals-n-pets" type="checkbox" />
                            <label class="checkbox" for="animals-n-pets">Animals & pets</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="baking" name="baking" type="checkbox" />
                            <label class="checkbox" for="baking">Baking</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="music" name="music" type="checkbox" />
                            <label class="checkbox" for="music">Music</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="health-n-fitness" name="health-n-fitness" type="checkbox" />
                            <label class="checkbox" for="health-n-fitness">Health & fitness</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="sport" name="sport" type="checkbox" />
                            <label class="checkbox" for="sport">Sport</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="organic-food" name="organic-food" type="checkbox" />
                            <label class="checkbox" for="organic-food">Organic food</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="food-n-drink" name="food-n-drink" type="checkbox" />
                            <label class="checkbox" for="food-n-drink">Food & drink</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="technology" name="technology" type="checkbox" />
                            <label class="checkbox" for="technology">Technology</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="photography" name="photography" type="checkbox" />
                            <label class="checkbox" for="photography">Photography</label>
                        </li>
                        <li class="categories__element categories__element--4column">
                            <input class="visually-hidden" id="sustainability" name="sustainability" type="checkbox" />
                            <label class="checkbox" for="sustainability">Sustainability</label>
                        </li>
                    </ul>

                    <div class="form__flex-field profile-page__ok-cancel">
                        <button class="button button--transparent-red" type="button">Cancel</button>
                        <button class="button button--red" type="submit">Save</button>
                    </div>
                </form>
            </div>
            <div class="tab__button-wrapper">
                <span class="tab__button">Edit info</span>|<span class="tab__button"
                >Add/edit Categories</span
                >
            </div>
            <!-- ------------------------- Select category end ------------------------- -->

            <!-- ------------------------ Select networks start ------------------------ -->
            <h2 class="tab__title">Network selection</h2>

            <div class="info-block">
                <form class="profile-page__form form">
                    <!-- prettier-ignore -->
                    <ul class="form__field-list">
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">Facebook</span>
                                <input class="form__input" type="text" name="fb-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-fb-link-on" name="is-fb-link-on" type="checkbox"/>
                                <label class="on-off" for="is-fb-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">Twitter</span>
                                <input class="form__input" type="text" name="tw-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-tw-link-on" name="is-tw-link-on" type="checkbox" />
                                <label class="on-off" for="is-tw-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">LinkedIn</span>
                                <input class="form__input" type="text" name="ln-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-ln-link-on" name="is-ln-link-on" type="checkbox" />
                                <label class="on-off" for="is-ln-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">Tumbler</span>
                                <input class="form__input" type="text" name="tm-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-tm-link-on" name="is-tm-link-on" type="checkbox" />
                                <label class="on-off" for="is-tm-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">YouTube</span>
                                <input class="form__input" type="text" name="yo-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-yo-link-on" name="is-yo-link-on" type="checkbox" />
                                <label class="on-off" for="is-yo-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">Patreon</span>
                                <input class="form__input" type="text" name="pt-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-pt-link-on" name="is-pt-link-on" type="checkbox" />
                                <label class="on-off" for="is-pt-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">Pinterest</span>
                                <input class="form__input" type="text" name="pn-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-pn-link-on" name="is-pn-link-on" type="checkbox" />
                                <label class="on-off" for="is-pn-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">Website</span>
                                <input class="form__input" type="text" name="ws-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-ws-link-on" name="is-ws-link-on" type="checkbox" />
                                <label class="on-off" for="is-ws-link-on"></label>
                            </label>
                        </li>
                        <li>
                            <label class="form__vertical-field">
                                <span class="form__label">Instagram</span>
                                <input class="form__input" type="text" name="in-link" placeholder="https://" />

                                <input class="visually-hidden" id="is-in-link-on" name="is-in-link-on" type="checkbox" />
                                <label class="on-off" for="is-in-link-on"></label>
                            </label>
                        </li>
                    </ul>

                    <div class="form__flex-field profile-page__ok-cancel">
                        <button class="button button--transparent-red" type="button">Cancel</button>
                        <button class="button button--red" type="submit">Save</button>
                    </div>
                </form>
            </div>
            <div class="tab__button-wrapper">
                <span class="tab__button">Edit info</span>|<span class="tab__button"
                >Add/edit Network</span
                >
            </div>
            <!-- ------------------------- Select networks end ------------------------- -->

            <!-- --------------------------- Rate card start --------------------------- -->
            <h2 class="tab__title">Rate Card</h2>

            <div class="info-block" id="rate-card-section">
                <form class="profile-page__form form">
                    <!-- prettier-ignore -->
                    <ul class="form__field-list">
                        <li class="form__flex-130">
                            <label class="form__vertical-field">
                                <span class="form__label">Facebook Post</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                            <label class="form__vertical-field">
                                <span class="form__label">Facebook Story</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                        </li>
                        <li class="form__flex-130">
                            <label class="form__vertical-field">
                                <span class="form__label">YouTube Video</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                        </li>
                        <li class="form__flex-130">
                            <label class="form__vertical-field">
                                <span class="form__label">Instagram Post</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                            <label class="form__vertical-field">
                                <span class="form__label">Instagram Story</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                            <label class="form__vertical-field">
                                <span class="form__label">Instagram Video</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                        </li>
                        <li class="form__flex-130">
                            <label class="form__vertical-field">
                                <span class="form__label">Twitter Post</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                        </li>
                        <li class="form__flex-130">
                            <label class="form__vertical-field">
                                <span class="form__label">Pinterest Post</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                        </li>
                        <li class="form__flex-130">
                            <label class="form__vertical-field">
                                <span class="form__label">LinkedIn Post</span>
                                <input class="form__input" type="text" name="" placeholder="$0.00" maxlength="10"/>
                            </label>
                        </li>
                    </ul>

                    <div class="form__flex-field profile-page__ok-cancel">
                        <button class="button button--transparent-red" type="button">Cancel</button>
                        <button class="button button--red" type="submit">Save</button>
                    </div>
                </form>
            </div>
            <div class="tab__button-wrapper">
                <span class="tab__button">Edit info</span>|<span class="tab__button"
                >Change Rate Card</span
                >
            </div>
            <!-- ---------------------------- Rate card end ---------------------------- -->

            <!-- ------------------------ Change password start ------------------------ -->
            <h2 class="tab__title">Change password</h2>

            <div class="info-block">
                <form class="profile-page__form form">
                    <label class="form__vertical-field">
                        <span class="form__label">Old password *</span>
                        <input class="form__input" type="password" name="old-password" required />
                    </label>

                    <label class="form__vertical-field">
                        <span class="form__label">New password *</span>
                        <input class="form__input" type="password" name="new-password" required />
                    </label>

                    <label class="form__vertical-field">
                        <span class="form__label">Repeat password *</span>
                        <input class="form__input" type="password" name="repeat-password" required />
                    </label>

                    <div class="form__flex-field profile-page__ok-cancel">
                        <button class="button button--transparent-red" type="button">Cancel</button>
                        <button class="button button--red" type="submit">Save</button>
                    </div>
                </form>
            </div>
            <div class="tab__button-wrapper">
                <span class="tab__button">Edit info</span>|<span class="tab__button"
                >Change password</span
                >
            </div>
            <!-- ------------------------- Change password end ------------------------- -->
        </section>
    </section>
    <!-- -------------------------- profile page end --------------------------- -->
@endsection
