<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link
            href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap"
            rel="stylesheet"
        />
        <link rel="stylesheet" href="css/style.min.css" type="text/css" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Influencer platform</title>
    </head>
    <body>
        <main class="login-page__wrapper">
            <div class="login-page__bg-container">
                <img class="login-page__bg-image" src="./image/bg-image.png" />
                <div class="login-page__bg-flex">
                    <h1>Welcome to Influencer Union!</h1>
                    <p class="login-page__description">
                        Register to become a member of Influencer Union's professional advertising network and
                        earn money by building partnerships with brands and businesses
                    </p>
                    <p class="login-page__term-text">
                        By creating an account you agree to the Influencer Union
                        <a href="terms.html">Terms of Service</a> &
                        <a href="privacy-policy.html">Privacy Policy</a>
                    </p>
                </div>
            </div>
            <div class="login-page__container">
                <h1 class="login-page__title">Create your account</h1>
                <form class="login-page__form login-form login-form--sign-up">
                    <label class="login-form__field login-form__field--sign-up">
                        <span class="login-form__label">Email</span>
                        <input
                            class="login-form__input"
                            type="email"
                            name="email"
                            placeholder="Enter your email address"
                            required
                        />
                    </label>
                    <div class="login-form__flex-field login-form__flex-field--sign-up">
                        <label class="login-form__field login-form__field--sign-up">
                            <span class="login-form__label">First name</span>
                            <input
                                class="login-form__input"
                                type="text"
                                name="first-name"
                                placeholder="Enter your first name"
                                required
                            />
                        </label>
                        <label class="login-form__field login-form__field--sign-up">
                            <span class="login-form__label">Last name</span>
                            <input
                                class="login-form__input"
                                type="text"
                                name="last-name"
                                placeholder="Enter your last name"
                                required
                            />
                        </label>
                    </div>
                    <label class="login-form__field login-form__field--sign-up">
                        <span class="login-form__label">Phone</span>
                        <input
                            class="login-form__input"
                            type="text"
                            name="phone"
                            placeholder="Enter your phone number"
                            required
                        />
                    </label>
                    <label class="login-form__field login-form__field--sign-up">
                        <span class="login-form__label">Password</span>
                        <input
                            class="login-form__input"
                            type="password"
                            name="password"
                            placeholder="Enter your password"
                            required
                        />
                    </label>
                    <label class="login-form__field login-form__field--sign-up">
                        <span class="login-form__label">Confirm password</span>
                        <input
                            class="login-form__input"
                            type="password"
                            name="confirm-password"
                            placeholder="Confirm your password"
                            required
                        />
                    </label>
                    <p class="login-form__description login-form__description--sign-up">
                        Already have an Influencer Union account? <a href="sign-in.html">Sign In</a>
                    </p>
                    <div
                        class="login-form__flex-field login-form__flex-field--sign-up"
                        style="margin-top: 20px"
                    >
                        <button class="button button--red" type="submit">Sign up</button>
                    </div>
                </form>
            </div>

            <button class="chat chat__open-button"></button>
        </main>
    </body>
</html>
