@extends('layouts.app')
@section('content')
<table class="table" style="width:100%;border:1px solid #937575">
    <thead style="width:100%">
    <tr>
        <th scope="col">Name</th>
        <th scope="col">First name</th>
        <th scope="col">Short name</th>
        <th scope="col">Email</th>
    </tr>
    </thead>
    <tbody style="text-align: center">
    <tr>
        <td scope="col">{{$all->name}}</td>
        <td scope="col">{{$all->first_name}}</td>
        <td scope="col">{{$all->short_name}}</td>
        <td scope="col">{{$all->email}}</td>
{{--        <img src="{{asset('img/'.$all->picture->data->url)}}" width="100px" height="100px">--}}
    </tr>
    </tbody>
</table>
    @endsection
