(() => {
  // hamburger menu
  const container = document.querySelector('.container');
  const hamburgerButton = document.querySelector('.menu__button');

  const userMenu = document.querySelector('.user-menu__wrapper');
  const userMenuButton = document.querySelector('.user-menu__button');

  const onHamburgerButtonClick = () => container.classList.toggle('container--opened-side-panel');
  const onUserMenuButtonClick = () => userMenu.classList.toggle('user-menu--opened');

  hamburgerButton && hamburgerButton.addEventListener('click', onHamburgerButtonClick);
  userMenuButton && userMenuButton.addEventListener('click', onUserMenuButtonClick);
})();
