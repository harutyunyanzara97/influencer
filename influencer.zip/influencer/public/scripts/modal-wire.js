(() => {
  // modal paypal
  const ANIMATION_DURATION = 500;
  let isWireAdded = false;

  const modalWire = document.getElementById('modal-wire');
  const buttonOpenWireModal = document.getElementById('button-open-wire');
  const modalWireCloseButton = modalWire && document.getElementById('modal-wire-close-button');
  const modalWireAddButton = modalWire && document.getElementById('modal-wire-add-button');

  const modalWireFields = modalWire.querySelectorAll('input');

  const modalShow = () => {
    document.body.style.overflowY = 'hidden';
    modalWire.classList.add('modal--animate');
    setTimeout(() => modalWire.classList.add('modal--opened'), 0);
    setTimeout(() => modalWire.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalHide = evt => {
    if (
      evt.target !== modalWire &&
      evt.target !== modalWireCloseButton &&
      evt.target !== modalWireAddButton
    )
      return;

    if (!isWireAdded) {
      modalWireFields.forEach(field => (field.value = ''));
    }

    document.body.style.overflowY = 'auto';
    modalWire.classList.add('modal--animate');
    modalWire.classList.remove('modal--opened');
    setTimeout(() => modalWire.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const onAddButtonClick = evt => {
    isWireAdded = true;
    buttonOpenWireModal.innerHTML = 'Edit';
    modalWireAddButton.innerHTML = 'Edit Wire Transfer';

    modalHide(evt);
  };

  buttonOpenWireModal && modalWire && buttonOpenWireModal.addEventListener('click', modalShow);
  modalWire && modalWire.addEventListener('click', modalHide);
  modalWireCloseButton && modalWireCloseButton.addEventListener('click', modalHide);
  modalWireAddButton && modalWireAddButton.addEventListener('click', onAddButtonClick);
})();
