(() => {
  const customSelectElements = document.querySelectorAll('.custom-select');
  const customSelectsAmount = customSelectElements.length;

  const optionDecoratorClick = evt => {
    const clickedOptionDecorator = evt.currentTarget;
    const selectElement =
      clickedOptionDecorator.parentNode.parentNode.querySelectorAll('select')[0];
    const selectDecorator = clickedOptionDecorator.parentNode.previousSibling;
    const optionsAmount = selectElement.length;

    for (let optionIndex = 0; optionIndex < optionsAmount; optionIndex++) {
      if (selectElement.options[optionIndex].innerHTML == clickedOptionDecorator.innerHTML) {
        selectElement.selectedIndex = optionIndex;
        selectDecorator.innerHTML = clickedOptionDecorator.innerHTML;
        const selectedOptionDecorators =
          clickedOptionDecorator.parentNode.querySelectorAll('.same-as-selected');

        selectedOptionDecorators.forEach(selectedOptionDecorator => {
          selectedOptionDecorator.removeAttribute('class');
        });

        clickedOptionDecorator.setAttribute('class', 'same-as-selected');

        const event = new Event('change');
        selectElement.dispatchEvent(event);
        break;
      }
    }
  };

  for (let customSelectIndex = 0; customSelectIndex < customSelectsAmount; customSelectIndex++) {
    const customSelect = customSelectElements[customSelectIndex].querySelectorAll('select')[0];
    const optionsAmount = customSelect.length;

    const selectDecorator = document.createElement('DIV');
    selectDecorator.setAttribute('class', 'select-selected');
    selectDecorator.innerHTML = customSelect.options[customSelect.selectedIndex].innerHTML;
    customSelectElements[customSelectIndex].appendChild(selectDecorator);

    const optionDecoratorsContainer = document.createElement('DIV');
    optionDecoratorsContainer.setAttribute('class', 'select-items select-hide');

    for (let optionIndex = 1; optionIndex < optionsAmount; optionIndex++) {
      const optionDecorator = document.createElement('DIV');
      optionDecorator.innerHTML = customSelect.options[optionIndex].innerHTML;

      optionDecorator.addEventListener('click', optionDecoratorClick);
      optionDecoratorsContainer.appendChild(optionDecorator);
    }
    customSelectElements[customSelectIndex].appendChild(optionDecoratorsContainer);
    selectDecorator.addEventListener('click', function (evt) {
      /* When the select box is clicked, close any other select boxes,
    and open/close the current select box: */
      evt.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle('select-hide');
      this.classList.toggle('select-arrow-active');
    });
  }

  function closeAllSelect(elmnt) {
    /* A function that will close all select boxes in the document,
  except the current select box: */
    var x,
      y,
      i,
      xl,
      yl,
      arrNo = [];
    x = document.getElementsByClassName('select-items');
    y = document.getElementsByClassName('select-selected');
    xl = x.length;
    yl = y.length;
    for (i = 0; i < yl; i++) {
      if (elmnt == y[i]) {
        arrNo.push(i);
      } else {
        y[i].classList.remove('select-arrow-active');
      }
    }
    for (i = 0; i < xl; i++) {
      if (arrNo.indexOf(i)) {
        x[i].classList.add('select-hide');
      }
    }
  }

  /* If the user clicks anywhere outside the select box,
then close all select boxes: */
  document.addEventListener('click', closeAllSelect);
})();
