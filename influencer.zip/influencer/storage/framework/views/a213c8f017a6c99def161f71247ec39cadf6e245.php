<form action="<?php echo e(url('/store')); ?>" method="post" class="pb-4" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div  class="d-flex">
                    <div class="flex-1 px-4">
                        <div class="form-group">
                            <label for="nameCampaign" class="fs-normal-12">Campaign Name:</label>
                            <input type="text" class="form-control h--50 fs-14-black text-left" name="title" id="nameCampaign" placeholder="Campaign Name">
                        </div>
                        <div class="form-group">
                            <label for="CampaignDetails" class="fs-normal-12">Creative</label>
                            <input type="text" class="form-control h--50 fs-14-black text-left" name="details" id="CampaignDetails" placeholder="Campaign Details">
                        </div>
                        <div class="form-group">
                            <label for="CampaignCategory" class="fs-normal-12">Category</label>
                            <br>
                            <select name="category[]">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="CampaignHashTags" class="fs-normal-12">Hashtags</label>
                            <input type="text" class="form-control h--50 fs-14-black text-left" name="hashtags" id="CampaignHashTags" placeholder="Post famous words">
                        </div>
                    </div>
                    <div class="flex-1 px-4">
                        <div class="form-group">
                            <label for="CampaignCost" class="fs-normal-12">Budget</label>
                            <input type="number" class="form-control h--50 fs-14-black text-left" name="per_post_rate" id="CampaignCost" placeholder="Cost Per Post Rate">
                        </div>


                        <div class="form-group">
                            <label for="CampaignDate" class="fs-normal-12">Start Date and End Date</label>
                            <input type="date" class="form-control h--50 fs-14-black text-left" name="start_date" id="CampaignDate" placeholder="Start Date">
                            <input type="date" class="form-control h--50 fs-14-black text-left" name="end_date" id="CampaignDate" placeholder="End Date">

                        </div>
                        <div class="form-group mt-4 pt-1 w-50">
                            <div class="input-group my-3 px-2 py-2 bg-white border-input">
                                <input id="upload" type="file" name="photo[]" onchange="readURL(this);" class="form-control">
                                <label id="upload-label" for="upload" class="h--50 fs-14-black text-left text-muted">
                                    <img src="img/photo-icon.png" alt="" class="mr-2">Upload Images (Not Mandatory)</label>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn-red mt-4 br-5 m-l--20">Submit</button>
            </form>
<div class="container">
    <div class="row lead">
        <div id="stars-existing" class="starrr" data-id="1" data-rating='4'></div>
        You gave a rating of <span id="count-existing">4</span> star(s)
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<!-- <script src="js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/gh/gitbrent/bootstrap4-toggle@3.6.1/js/bootstrap4-toggle.min.js"></script> -->
<script src="<?php echo e(asset('js/clientDashboard.js')); ?>" type="text/javascript"></script>

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/ststistics.js')); ?>"></script>

<script>
    function openNav() {
        document.getElementById("left-sidebar-fix").classList.add("open-sidebar");
        document.getElementById("main").style.marginLeft = "240px";
        document.getElementById("openbtn").classList.add("d-none");
        document.getElementById("openbtn").classList.remove("d-block");
        document.getElementById("closebtn").classList.remove("d-none");
        document.getElementById("closebtn").classList.add("d-block");
    }

    function closeNav() {
        document.getElementById("left-sidebar-fix").classList.remove("open-sidebar");
        document.getElementById("main").style.marginLeft = "80px";
        document.getElementById("closebtn").classList.remove("d-block");
        document.getElementById("closebtn").classList.add("d-none");
        document.getElementById("openbtn").classList.add("d-block");
    }


    var __slice = [].slice;

    (function($, window) {
        var Starrr;

        Starrr = (function() {
            Starrr.prototype.defaults = {
                rating: void 0,
                numStars: 5,
                change: function(e, value) {}
            };

            function Starrr($el, options) {
                var i, _, _ref,
                    _this = this;

                this.options = $.extend({}, this.defaults, options);
                this.$el = $el;
                _ref = this.defaults;
                for (i in _ref) {
                    _ = _ref[i];
                    if (this.$el.data(i) != null) {
                        this.options[i] = this.$el.data(i);
                    }
                }
                this.createStars();
                this.syncRating();
                this.$el.on('mouseover.starrr', 'i', function(e) {
                    return _this.syncRating(_this.$el.find('i').index(e.currentTarget) + 1);
                });
                this.$el.on('mouseout.starrr', function() {
                    return _this.syncRating();
                });
                this.$el.on('click.starrr', 'i', function(e) {
                    return _this.setRating(_this.$el.find('i').index(e.currentTarget) + 1);
                });
                this.$el.on('starrr:change', this.options.change);
            }

            Starrr.prototype.createStars = function() {
                var _i, _ref, _results;

                _results = [];
                for (_i = 1, _ref = this.options.numStars; 1 <= _ref ? _i <= _ref : _i >= _ref; 1 <= _ref ? _i++ : _i--) {
                    _results.push(this.$el.append("<i class='fa fa-star-o rate'></i>"));
                }
                return _results;
            };

            Starrr.prototype.setRating = function(rating) {
                if (this.options.rating === rating) {
                    rating = void 0;
                }
                this.options.rating = rating;
                this.syncRating();
                return this.$el.trigger('starrr:change', rating);
            };

            Starrr.prototype.syncRating = function(rating) {
                var i, _i, _j, _ref;

                rating || (rating = this.options.rating);
                if (rating) {
                    for (i = _i = 0, _ref = rating - 1; 0 <= _ref ? _i <= _ref : _i >= _ref; i = 0 <= _ref ? ++_i : --_i) {
                        this.$el.find('i').eq(i).removeClass('fa-star-o rate').addClass('fa-star rate');
                    }
                }
                if (rating && rating < 5) {
                    for (i = _j = rating; rating <= 4 ? _j <= 4 : _j >= 4; i = rating <= 4 ? ++_j : --_j) {
                        this.$el.find('i').eq(i).removeClass('fa-star rate').addClass('fa-star-o rate');
                    }
                }
                if (!rating) {
                    return this.$el.find('i').removeClass('fa-star rate').addClass('fa-star-o rate');
                }
            };

            return Starrr;

        })();
        return $.fn.extend({
            starrr: function() {
                var args, option;

                option = arguments[0], args = 2 <= arguments.length ? __slice.call(arguments, 1) : [];
                return this.each(function() {
                    var data;

                    data = $(this).data('star-rating');
                    if (!data) {
                        $(this).data('star-rating', (data = new Starrr($(this), option)));
                    }
                    if (typeof option === 'string') {
                        return data[option].apply(data, args);
                    }
                });
            }
        });
    })(window.jQuery, window);

    $(function() {
        return $(".starrr").starrr();
    });

    $( document ).ready(function() {
        $('#stars').on('starrr:change', function(e, value){
            $('#count').html(value);
        });

        $('#stars-existing').on('starrr:change', function(e, value){
            $('#count-existing').html(value);
            let rate = $(this);
            $.ajax({
                type: "post",
                url: '/rate',
                data: {_token: $('meta[name="csrf-token"]').attr('content'), id: value},
                success: function (r) {
                }
            })
        });
    });
    //
    // $(document).on('click', '.rate', function (event) {
    //     event.preventDefault();
    //     let rate = $(this);
    //
    //     $.ajax({
    //         type: "post",
    //         url: '/rate',
    //         data: {_token: $('meta[name="csrf-token"]').attr('content'), id: id, type: type},
    //         success: function (r) {
    //         }
    //     })
    // })

</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\influencer\resources\views/create-campaign.blade.php ENDPATH**/ ?>