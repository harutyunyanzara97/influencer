<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\influencer\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>