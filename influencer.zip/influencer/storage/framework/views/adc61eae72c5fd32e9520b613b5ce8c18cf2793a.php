    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Plans</div>
                    <div class="card-body">
                        <ul class="list-group">
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item clearfix">
                                    <div class="pull-left">
                                        <h5><?php echo e($plan->name); ?></h5>
                                        <h5>$<?php echo e(number_format($plan->cost, 2)); ?> monthly</h5>
                                        <h5><?php echo e($plan->description); ?></h5>
                                        <a href="" class="btn btn-outline-dark pull-right">Choose</a>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\influencer\resources\views/index.blade.php ENDPATH**/ ?>
