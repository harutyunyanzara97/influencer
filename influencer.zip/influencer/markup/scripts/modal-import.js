(() => {
  // modal import
  const ANIMATION_DURATION = 500;

  const modalImport = document.querySelector('#modal-import');
  const buttonOpenImportModal = document.querySelector('#button-open-import');
  const modalImportCloseButton =
    modalImport && modalImport.querySelector('#modal-import-close-button');

  const modalImportShow = () => {
    document.body.style.overflowY = 'hidden';
    modalImport.classList.add('modal--animate');
    setTimeout(() => modalImport.classList.add('modal--opened'), 0);
    setTimeout(() => modalImport.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalImportHide = evt => {
    if (evt.target !== modalImport && evt.target !== modalImportCloseButton) return;
    document.body.style.overflowY = 'auto';
    modalImport.classList.add('modal--animate');
    modalImport.classList.remove('modal--opened');
    setTimeout(() => modalImport.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  buttonOpenImportModal &&
    modalImport &&
    buttonOpenImportModal.addEventListener('click', modalImportShow);
  modalImport && modalImport.addEventListener('click', modalImportHide);
  modalImportCloseButton && modalImportCloseButton.addEventListener('click', modalImportHide);
})();
