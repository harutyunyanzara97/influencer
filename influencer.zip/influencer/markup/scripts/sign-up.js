(() => {
  const getScript = scriptName => {
    var scriptElement = document.createElement('script');
    scriptElement.type = 'text/javascript';
    scriptElement.src = scriptName;
    document.body.appendChild(scriptElement);
  };

  [
    './scripts/tab-changes.min.js',
    './scripts/payment-plan-change.min.js',
    './scripts/modal-credit-card.min.js',
    './scripts/modal-paypal.min.js',
    './scripts/modal-e-transfer.min.js',
    './scripts/modal-wire.min.js',
    './scripts/modal-billing-email.min.js',
    './scripts/custom-select.min.js',
    './scripts/create-rate-card.min.js',
    './scripts/modal-payment-method-change.min.js',
  ].forEach(path => getScript(path));
})();
