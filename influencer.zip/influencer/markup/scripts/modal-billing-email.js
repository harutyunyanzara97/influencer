(() => {
  // modal e-transfer
  const ANIMATION_DURATION = 500;
  // let isETransferAdded = false;

  const modal = document.getElementById('modal-billing-email');
  const buttonOpenModal = document.getElementById('button-open-billing-email-modal');
  const modalCloseButton = modal && document.getElementById('modal-billing-email-close-button');
  const modalAddButton = modal && document.getElementById('modal-billing-email-add-button');

  const BillingEmailText = document.getElementById('billing-email');
  const billingEmailElement = document.getElementById('billing-email-address');

  const modalShow = () => {
    document.body.style.overflowY = 'hidden';
    modal.classList.add('modal--animate');
    setTimeout(() => modal.classList.add('modal--opened'), 0);
    setTimeout(() => modal.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalHide = evt => {
    if (evt.target !== modal && evt.target !== modalCloseButton && evt.target !== modalAddButton)
      return;

    document.body.style.overflowY = 'auto';
    modal.classList.add('modal--animate');
    modal.classList.remove('modal--opened');
    setTimeout(() => modal.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const onAddButtonClick = evt => {
    if (billingEmailElement && BillingEmailText)
      BillingEmailText.innerText = billingEmailElement.value;

    modalHide(evt);
  };

  if (billingEmailElement && BillingEmailText)
    billingEmailElement.value = BillingEmailText.innerText;

  buttonOpenModal && modal && buttonOpenModal.addEventListener('click', modalShow);
  modal && modal.addEventListener('click', modalHide);
  modalCloseButton && modalCloseButton.addEventListener('click', modalHide);
  modalAddButton && modalAddButton.addEventListener('click', onAddButtonClick);
})();
