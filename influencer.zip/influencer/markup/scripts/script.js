(() => {
  const getScript = scriptName => {
    const scriptElement = document.createElement('script');
    scriptElement.type = 'text/javascript';
    scriptElement.src = scriptName;
    document.body.appendChild(scriptElement);
  };

  [
    './scripts/hamburger-menu.min.js',
    './scripts/modal-payment-method-change.min.js',
    './scripts/modal-credit-card.min.js',
    './scripts/modal-paypal.min.js',
    './scripts/modal-e-transfer.min.js',
    './scripts/modal-wire.min.js',
    './scripts/modal-billing-email.min.js',
    './scripts/custom-select.min.js',
    './scripts/modal-filter.min.js',
    './scripts/modal-view.min.js',
    './scripts/modal-influencer.min.js',
    './scripts/modal-open-topic.min.js',
    './scripts/create-rate-card.min.js',
    './scripts/add-remove-from-list.min.js',
  ].forEach(path => getScript(path));
})();
