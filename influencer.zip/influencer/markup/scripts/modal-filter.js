(() => {
  // modal filter
  const ANIMATION_DURATION = 500;

  const modalFilter = document.querySelector('#modal-filter');
  const buttonOpenFilterModal = document.querySelector('#button-open-filter');
  const modalFilterCloseButton =
    modalFilter && modalFilter.querySelector('#modal-filter-close-button');

  const modalFilterShow = () => {
    document.body.style.overflowY = 'hidden';
    modalFilter.classList.add('modal--animate');
    setTimeout(() => modalFilter.classList.add('modal--opened'), 0);
    setTimeout(() => modalFilter.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalFilterHide = evt => {
    if (evt.target !== modalFilter && evt.target !== modalFilterCloseButton) return;
    document.body.style.overflowY = 'auto';
    modalFilter.classList.add('modal--animate');
    modalFilter.classList.remove('modal--opened');
    setTimeout(() => modalFilter.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  buttonOpenFilterModal &&
    modalFilter &&
    buttonOpenFilterModal.addEventListener('click', modalFilterShow);
  modalFilter && modalFilter.addEventListener('click', modalFilterHide);
  modalFilterCloseButton && modalFilterCloseButton.addEventListener('click', modalFilterHide);
})();
