(() => {
  const reteCardSection = document.querySelector('#rate-card-section');
  const fields = (reteCardSection && reteCardSection.querySelectorAll('input')) || [];

  const onFieldInput = evt => {
    let value = '$' + evt.target.value.replace(/[^0-9.]+/g, '');
    evt.target.value = value === '$' || value === '$.' ? '' : value;
  };

  fields.forEach(field => {
    field.addEventListener('input', onFieldInput);
  });
})();
