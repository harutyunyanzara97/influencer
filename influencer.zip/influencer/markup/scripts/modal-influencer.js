(() => {
  // modal influencer
  const ANIMATION_DURATION = 500;

  const modalInfluencer = document.querySelector('#modal-influencer');
  const buttonOpenInfluencerModalList = document.querySelectorAll('.button-open-influencer-info');
  const modalInfluencerCloseButton =
    modalInfluencer && modalInfluencer.querySelector('#modal-influencer-close-button');

  const modalInfluencerShow = () => {
    document.body.style.overflowY = 'hidden';
    modalInfluencer.classList.add('modal--animate');
    setTimeout(() => modalInfluencer.classList.add('modal--opened'), 0);
    setTimeout(() => modalInfluencer.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalInfluencerHide = evt => {
    if (evt.target !== modalInfluencer && evt.target !== modalInfluencerCloseButton) return;
    document.body.style.overflowY = 'auto';
    modalInfluencer.classList.add('modal--animate');
    modalInfluencer.classList.remove('modal--opened');
    setTimeout(() => modalInfluencer.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  buttonOpenInfluencerModalList &&
    modalInfluencer &&
    buttonOpenInfluencerModalList.forEach(element =>
      element.addEventListener('click', modalInfluencerShow),
    );
  modalInfluencer && modalInfluencer.addEventListener('click', modalInfluencerHide);
  modalInfluencerCloseButton &&
    modalInfluencerCloseButton.addEventListener('click', modalInfluencerHide);
})();
