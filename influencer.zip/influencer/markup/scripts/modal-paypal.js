(() => {
  // modal paypal
  const ANIMATION_DURATION = 500;
  let isPaypalAdded = false;

  const modalPaypal = document.getElementById('modal-paypal');
  const buttonOpenPaypalModal = document.getElementById('button-open-paypal');
  const modalPaypalCloseButton =
    modalPaypal && document.getElementById('modal-paypal-close-button');
  const modalPaypalAddButton = modalPaypal && document.getElementById('modal-paypal-add-button');

  const modalPaypalName = document.getElementById('paypal-name');
  const modalPaypalEmail = document.getElementById('paypal-email');

  const modalShow = () => {
    document.body.style.overflowY = 'hidden';
    modalPaypal.classList.add('modal--animate');
    setTimeout(() => modalPaypal.classList.add('modal--opened'), 0);
    setTimeout(() => modalPaypal.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalHide = evt => {
    if (
      evt.target !== modalPaypal &&
      evt.target !== modalPaypalCloseButton &&
      evt.target !== modalPaypalAddButton
    )
      return;

    if (!isPaypalAdded) {
      modalPaypalName.value = '';
      modalPaypalEmail.value = '';
    }

    document.body.style.overflowY = 'auto';
    modalPaypal.classList.add('modal--animate');
    modalPaypal.classList.remove('modal--opened');
    setTimeout(() => modalPaypal.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const onAddButtonClick = evt => {
    isPaypalAdded = true;
    buttonOpenPaypalModal.innerHTML = 'Edit';
    modalPaypalAddButton.innerHTML = 'Edit Paypal Account';

    modalHide(evt);
  };

  buttonOpenPaypalModal &&
    modalPaypal &&
    buttonOpenPaypalModal.addEventListener('click', modalShow);
  modalPaypal && modalPaypal.addEventListener('click', modalHide);
  modalPaypalCloseButton && modalPaypalCloseButton.addEventListener('click', modalHide);
  modalPaypalAddButton && modalPaypalAddButton.addEventListener('click', onAddButtonClick);
})();
