(() => {
  // tab changes
  const paymentSection = document.getElementById('payment-section');
  const plansSection = document.getElementById('plans-section');
  const categoriesSection = document.getElementById('categories-section');
  const networkSection = document.getElementById('network-section');
  const rateCardSection = document.getElementById('rate-card-section');

  const accountInfoList = document.querySelectorAll('.account-info-progress span');

  const paymentNextButton = document.getElementById('payment-next-button');
  const plansPrevButton = document.getElementById('plans-prev-button');
  const plansNextButton = document.getElementById('plans-next-button');
  const categoriesPrevButton = document.getElementById('categories-prev-button');
  const categoriesNextButton = document.getElementById('categories-next-button');
  const networkPrevButton = document.getElementById('network-prev-button');
  const networkNextButton = document.getElementById('network-next-button');
  const rateCardPrevButton = document.getElementById('rate-card-prev-button');

  const hideAllSections = () => {
    paymentSection && paymentSection.classList.add('hidden');
    plansSection && plansSection.classList.add('hidden');
    categoriesSection && categoriesSection.classList.add('hidden');
    networkSection && networkSection.classList.add('hidden');
    rateCardSection && rateCardSection.classList.add('hidden');
  };

  const setCurrentInfoItem = currentIndex => {
    accountInfoList.forEach((accountInfo, index) => {
      accountInfo.classList.remove('account-info-progress__element--red');
      accountInfo.classList.remove('account-info-progress__element--red-current');

      if (index < currentIndex) {
        accountInfo.classList.add('account-info-progress__element--red');
      }
      if (index === currentIndex) {
        accountInfo.classList.add('account-info-progress__element--red-current');
      }
    });
  };

  const showPaymentSection = () => {
    hideAllSections();
    setCurrentInfoItem(0);
    paymentSection && paymentSection.classList.remove('hidden');
  };
  const showPlansSection = () => {
    hideAllSections();
    setCurrentInfoItem(1);
    plansSection && plansSection.classList.remove('hidden');
  };
  const showCategoriesSection = () => {
    hideAllSections();
    // for brand type
    if (plansSection) setCurrentInfoItem(2);
    else setCurrentInfoItem(1); // for influencer type
    categoriesSection && categoriesSection.classList.remove('hidden');
  };
  const showNetworkSection = () => {
    hideAllSections();
    // for brand type
    if (plansSection) setCurrentInfoItem(3);
    else setCurrentInfoItem(2); // for influencer type
    networkSection && networkSection.classList.remove('hidden');
  };
  const showRateCardSection = () => {
    hideAllSections();

    setCurrentInfoItem(3); // for influencer type
    rateCardSection && rateCardSection.classList.remove('hidden');
  };

  paymentNextButton &&
    plansPrevButton &&
    paymentNextButton.addEventListener('click', showPlansSection); // for brand type
  paymentNextButton &&
    !plansPrevButton &&
    paymentNextButton.addEventListener('click', showCategoriesSection); // for influencer type

  plansPrevButton && plansPrevButton.addEventListener('click', showPaymentSection);
  plansNextButton && plansNextButton.addEventListener('click', showCategoriesSection);

  categoriesPrevButton &&
    plansPrevButton &&
    categoriesPrevButton.addEventListener('click', showPlansSection); // for brand type
  categoriesPrevButton &&
    !plansPrevButton &&
    categoriesPrevButton.addEventListener('click', showPaymentSection); // for influencer type

  categoriesNextButton && categoriesNextButton.addEventListener('click', showNetworkSection);
  networkPrevButton && networkPrevButton.addEventListener('click', showCategoriesSection);
  networkNextButton && networkNextButton.addEventListener('click', showRateCardSection);
  rateCardPrevButton && rateCardPrevButton.addEventListener('click', showNetworkSection);

  hideAllSections();
  setCurrentInfoItem(0);
  paymentSection && paymentSection.classList.remove('hidden');
})();
