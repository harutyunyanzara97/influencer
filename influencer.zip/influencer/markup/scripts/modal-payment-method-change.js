(() => {
  const paymentMethodElement = document.querySelector('#payment-method');

  const openCardButton = document.getElementById('button-open-card');
  const deleteCardButton = document.getElementById('button-delete-card');
  const openPaypalButton = document.getElementById('button-open-paypal');
  const openETransferButton = document.getElementById('button-open-e-transfer');
  const openWireButton = document.getElementById('button-open-wire');

  const onPaymentMethodChange = evt => {
    selectedIndex = evt.target.selectedIndex;

    openCardButton.style.display = 'none';
    openCardButton.disabled = false;
    deleteCardButton.style.display = 'none';
    openPaypalButton.style.display = 'none';
    openETransferButton.style.display = 'none';
    openWireButton.style.display = 'none';

    switch (selectedIndex) {
      default:
        openCardButton.disabled = true;
        openCardButton.style.display = 'block';
        break;
      case 1:
        openCardButton.style.display = 'block';
        deleteCardButton.style.display = 'block';
        break;
      case 2:
        openPaypalButton.style.display = 'block';
        break;
      case 3:
        openETransferButton.style.display = 'block';
        break;
      case 4:
        openWireButton.style.display = 'block';
        break;
    }
  };

  if (openCardButton) openCardButton.disabled = true;
  if (deleteCardButton) deleteCardButton.style.display = 'none';

  paymentMethodElement && paymentMethodElement.addEventListener('change', onPaymentMethodChange);
})();
