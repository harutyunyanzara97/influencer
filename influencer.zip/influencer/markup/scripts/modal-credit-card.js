(() => {
  // modal card
  const ANIMATION_DURATION = 500;
  let isCardAdded = false;

  const modalCard = document.getElementById('modal-card');
  const buttonOpenCardModal = document.getElementById('button-open-card');
  const buttonDeleteCard = document.getElementById('button-delete-card');
  const modalCardCloseButton = modalCard && document.getElementById('modal-card-close-button');
  const modalCardAddButton = modalCard && document.getElementById('modal-card-add-button');

  const modalCardName = document.getElementById('card-name');
  const modalCardNumber = document.getElementById('card-number');
  const modalCardMM = document.getElementById('card-mm');
  const modalCardYYYY = document.getElementById('card-yyyy');
  const modalCardCVC = document.getElementById('card-cvc');

  const setFieldsEmpty = () => {
    modalCardName.value = '';
    modalCardNumber.value = '';
    modalCardMM.value = '';
    modalCardYYYY.value = '';
    modalCardCVC.value = '';
  };

  const setButtonsNameTo = prefix => {
    buttonOpenCardModal.innerHTML = prefix;
    modalCardAddButton.innerHTML = `${prefix} Credit Card`;
  };

  const modalShow = () => {
    document.body.style.overflowY = 'hidden';
    modalCard.classList.add('modal--animate');
    setTimeout(() => modalCard.classList.add('modal--opened'), 0);
    setTimeout(() => modalCard.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalHide = evt => {
    if (
      evt.target !== modalCard &&
      evt.target !== modalCardCloseButton &&
      evt.target !== modalCardAddButton
    )
      return;

    if (!isCardAdded) setFieldsEmpty();

    document.body.style.overflowY = 'auto';
    modalCard.classList.add('modal--animate');
    modalCard.classList.remove('modal--opened');
    setTimeout(() => modalCard.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const setDeleteCardVisibility = visibility => {
    buttonDeleteCard && visibility && buttonDeleteCard.classList.remove('hidden');
    buttonDeleteCard && !visibility && buttonDeleteCard.classList.add('hidden');
  };

  const onAddButtonClick = evt => {
    isCardAdded = true;
    setButtonsNameTo('Edit');
    setDeleteCardVisibility(true);

    modalHide(evt);
  };

  const onDeleteButtonClick = () => {
    isCardAdded = false;

    setFieldsEmpty();
    setButtonsNameTo('Add');
    setDeleteCardVisibility(false);
  };

  const filterCardName = evt => {
    evt.target.value = evt.target.value.replace(/[^A-Za-z ]+/g, '');
  };
  const filterCardNumber = evt => {
    evt.target.value = evt.target.value.replace(/[^0-9]+/g, '');
  };
  const filterCardMM = evt => {
    evt.target.value = evt.target.value.replace(/[^0-9]+/g, '');
    if (evt.target.value < 1) evt.target.value = 1;
    if (evt.target.value > 12) evt.target.value = 12;
  };
  const filterCardYYYY = evt => {
    evt.target.value = evt.target.value.replace(/[^0-9]+/g, '');
    if (evt.target.value < 1970 && evt.target.value.length === 4) evt.target.value = 1970;
    if (evt.target.value > 2200) evt.target.value = 2200;
  };
  const filterCardCVC = evt => {
    evt.target.value = evt.target.value.replace(/[^0-9]+/g, '');
  };

  if (buttonOpenCardModal) buttonOpenCardModal.style.marginLeft = 'auto';
  if (buttonDeleteCard) buttonDeleteCard.style.marginLeft = '5px';
  setDeleteCardVisibility(false);

  buttonOpenCardModal && modalCard && buttonOpenCardModal.addEventListener('click', modalShow);
  buttonOpenCardModal &&
    modalCard &&
    buttonDeleteCard.addEventListener('click', onDeleteButtonClick);
  modalCard && modalCard.addEventListener('click', modalHide);
  modalCardCloseButton && modalCardCloseButton.addEventListener('click', modalHide);
  modalCardAddButton && modalCardAddButton.addEventListener('click', onAddButtonClick);

  modalCardName && modalCardName.addEventListener('input', filterCardName);
  modalCardNumber && modalCardNumber.addEventListener('input', filterCardNumber);
  modalCardMM && modalCardMM.addEventListener('input', filterCardMM);
  modalCardYYYY && modalCardYYYY.addEventListener('input', filterCardYYYY);
  modalCardCVC && modalCardCVC.addEventListener('input', filterCardCVC);
})();
