(() => {
  // hamburger menu
  const container = document.querySelector('.container');
  const hamburgerButton = document.querySelector('.menu__button');

  const userMenu = document.querySelector('.user-menu__wrapper');
  const userMenuButton = document.querySelector('.user-menu__button');

  const onHamburgerButtonClick = () => {
    const storage = window.localStorage;

    container.classList.toggle('container--opened-side-panel');
    storage.setItem(
      'isHamburgerMenuOpen',
      container.classList.contains('container--opened-side-panel'),
    );
  };
  const onUserMenuButtonClick = () => {
    const storage = window.localStorage;

    userMenu.classList.toggle('user-menu--opened');
    storage.setItem('isUserMenuOpen', userMenu.classList.contains('user-menu--opened'));
  };

  const storage = window.localStorage;
  try {
    storage.getItem('isHamburgerMenuOpen') === 'true' && onHamburgerButtonClick();
    storage.getItem('isUserMenuOpen') === 'true' && onUserMenuButtonClick();
  } catch (error) {}

  hamburgerButton && hamburgerButton.addEventListener('click', onHamburgerButtonClick);
  userMenuButton && userMenuButton.addEventListener('click', onUserMenuButtonClick);
})();
