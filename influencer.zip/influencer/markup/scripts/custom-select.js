(() => {
  const customSelectElements = document.querySelectorAll('.custom-select');
  const customSelectsAmount = customSelectElements.length;

  const optionDecoratorClick = evt => {
    const clickedOptionDecorator = evt.currentTarget;
    const selectElement =
      clickedOptionDecorator.parentNode.parentNode.querySelectorAll('select')[0];
    const selectDecorator = clickedOptionDecorator.parentNode.previousSibling;
    const optionsAmount = selectElement.length;

    for (let optionIndex = 0; optionIndex < optionsAmount; optionIndex++) {
      if (selectElement.options[optionIndex].innerHTML == clickedOptionDecorator.innerHTML) {
        selectElement.selectedIndex = optionIndex;
        selectDecorator.innerHTML = clickedOptionDecorator.innerHTML;
        const selectedOptionDecorators =
          clickedOptionDecorator.parentNode.querySelectorAll('.same-as-selected');

        selectedOptionDecorators.forEach(selectedOptionDecorator => {
          selectedOptionDecorator.removeAttribute('class');
        });

        clickedOptionDecorator.setAttribute('class', 'same-as-selected');

        const event = new Event('change');
        selectElement.dispatchEvent(event);
        break;
      }
    }
  };

  const closeAllCustomSelect = currentElement => {
    let selectDecoratorsIndexList = [];

    const optionDecorators = document.getElementsByClassName('select-items');
    const selectDecorators = document.getElementsByClassName('select-selected');
    const optionDecoratorsAmount = optionDecorators.length;
    const selectDecoratorsAmount = selectDecorators.length;
    for (
      let selectDecoratorIndex = 0;
      selectDecoratorIndex < selectDecoratorsAmount;
      selectDecoratorIndex++
    ) {
      if (currentElement == selectDecorators[selectDecoratorIndex]) {
        selectDecoratorsIndexList.push(selectDecoratorIndex);
      } else {
        selectDecorators[selectDecoratorIndex].classList.remove('select-arrow-active');
      }
    }
    for (
      let optionDecoratorIndex = 0;
      optionDecoratorIndex < optionDecoratorsAmount;
      optionDecoratorIndex++
    ) {
      if (selectDecoratorsIndexList.indexOf(optionDecoratorIndex)) {
        optionDecorators[optionDecoratorIndex].classList.add('select-hide');
      }
    }
  };

  for (let customSelectIndex = 0; customSelectIndex < customSelectsAmount; customSelectIndex++) {
    const customSelect = customSelectElements[customSelectIndex].querySelectorAll('select')[0];
    const optionsAmount = customSelect.length;

    const selectDecorator = document.createElement('DIV');
    selectDecorator.setAttribute('class', 'select-selected');
    selectDecorator.innerHTML = customSelect.options[customSelect.selectedIndex].innerHTML;
    customSelectElements[customSelectIndex].appendChild(selectDecorator);

    const optionDecoratorsContainer = document.createElement('DIV');
    optionDecoratorsContainer.setAttribute('class', 'select-items select-hide');

    for (let optionIndex = 1; optionIndex < optionsAmount; optionIndex++) {
      const optionDecorator = document.createElement('DIV');
      optionDecorator.innerHTML = customSelect.options[optionIndex].innerHTML;

      optionDecorator.addEventListener('click', optionDecoratorClick);
      optionDecoratorsContainer.appendChild(optionDecorator);
    }
    customSelectElements[customSelectIndex].appendChild(optionDecoratorsContainer);
    selectDecorator.addEventListener('click', function (evt) {
      evt.stopPropagation();
      closeAllCustomSelect(this);
      this.nextSibling.classList.toggle('select-hide');
      this.classList.toggle('select-arrow-active');
    });
  }

  document.addEventListener('click', closeAllCustomSelect);
})();
