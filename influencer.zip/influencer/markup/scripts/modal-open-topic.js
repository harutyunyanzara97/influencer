(() => {
  // open topic modal
  const ANIMATION_DURATION = 500;

  const modalTopic = document.querySelector('#modal-topic');
  const influencerTopicCardList = document.querySelector('.topic__card-list');
  const modalTopicCloseButton = modalTopic && modalTopic.querySelector('#modal-topic-close-button');
  const modalTopicBackButton = modalTopic && modalTopic.querySelector('#modal-topic-back-button');

  const modalTopicHide = evt => {
    if (
      evt.target !== modalTopic &&
      evt.target !== modalTopicCloseButton &&
      evt.target !== modalTopicBackButton
    )
      return;
    document.body.style.overflowY = 'auto';
    modalTopic.classList.add('modal--animate');
    modalTopic.classList.remove('modal--opened');
    setTimeout(() => modalTopic.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalTopicShow = evt => {
    if (evt.target.closest('.topic__card')) {
      modalTopic.classList.add('modal--animate');
      setTimeout(() => modalTopic.classList.add('modal--opened'), 0);
      setTimeout(() => modalTopic.classList.remove('modal--animate'), ANIMATION_DURATION);
    }
  };

  influencerTopicCardList &&
    modalTopic &&
    influencerTopicCardList.addEventListener('click', modalTopicShow);
  modalTopic && modalTopic.addEventListener('click', modalTopicHide);
  modalTopicCloseButton && modalTopicCloseButton.addEventListener('click', modalTopicHide);
  modalTopicBackButton && modalTopicBackButton.addEventListener('click', modalTopicHide);
})();
