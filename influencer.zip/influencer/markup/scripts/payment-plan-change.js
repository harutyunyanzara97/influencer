(() => {
  // payment plan radio
  const paymentPlanBasic = document.getElementById('payment-plan-basic');
  const paymentPlanProfessional = document.getElementById('payment-plan-professional');
  const paymentPlanBusiness = document.getElementById('payment-plan-business');

  const planFeaturesBasic = document.getElementById('plan-feature-basic');
  const planFeaturesProfessional = document.getElementById('plan-feature-professional');
  const planFeaturesBusiness = document.getElementById('plan-feature-business');

  const showFeatureForCurrentPlan = () => {
    planFeaturesBasic && planFeaturesBasic.classList.add('hidden');
    planFeaturesProfessional && planFeaturesProfessional.classList.add('hidden');
    planFeaturesBusiness && planFeaturesBusiness.classList.add('hidden');

    if (paymentPlanBasic && paymentPlanBasic.checked) planFeaturesBasic.classList.remove('hidden');
    if (paymentPlanProfessional && paymentPlanProfessional.checked)
      planFeaturesProfessional.classList.remove('hidden');
    if (paymentPlanBusiness && paymentPlanBusiness.checked)
      planFeaturesBusiness.classList.remove('hidden');
  };

  paymentPlanBasic && paymentPlanBasic.addEventListener('change', showFeatureForCurrentPlan);
  paymentPlanProfessional &&
    paymentPlanProfessional.addEventListener('change', showFeatureForCurrentPlan);
  paymentPlanBusiness && paymentPlanBusiness.addEventListener('change', showFeatureForCurrentPlan);

  showFeatureForCurrentPlan();
})();
