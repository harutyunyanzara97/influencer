(() => {
  // modal view
  const ANIMATION_DURATION = 500;
  const modalView = document.querySelector('#modal-view');
  const buttonOpenViewModal = document.querySelector('#button-open-view');
  const modalViewCloseButton = modalView && modalView.querySelector('#modal-view-close-button');

  const modalViewShow = () => {
    document.body.style.overflowY = 'hidden';
    modalView.classList.add('modal--animate');
    setTimeout(() => modalView.classList.add('modal--opened'), 0);
    setTimeout(() => modalView.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalViewHide = evt => {
    if (evt.target !== modalView && evt.target !== modalViewCloseButton) return;
    document.body.style.overflowY = 'auto';
    modalView.classList.add('modal--animate');
    modalView.classList.remove('modal--opened');
    setTimeout(() => modalView.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  buttonOpenViewModal && modalView && buttonOpenViewModal.addEventListener('click', modalViewShow);
  modalView && modalView.addEventListener('click', modalViewHide);
  modalViewCloseButton && modalViewCloseButton.addEventListener('click', modalViewHide);

  // view options change
  const viewOptions = document.querySelector('.view-options');
  const viewOptionsCheckbox = document.querySelectorAll('input[ data-column-name]');

  const localStorage = window.localStorage;

  const setColumnVisibility = (columnName, visibility) => {
    const tdList = document.querySelectorAll(
      `.influencers__row-${columnName}, .influencers__col-${columnName}`,
    );

    if (visibility) {
      tdList.forEach(td => td.classList.remove('hidden'));
    } else {
      tdList.forEach(td => td.classList.add('hidden'));
    }
  };

  const viewOptionChange = evt => {
    setColumnVisibility(evt.target.dataset.columnName, evt.target.checked);
    localStorage.setItem(evt.target.dataset.columnName, evt.target.checked);
  };

  viewOptionsCheckbox &&
    viewOptionsCheckbox.forEach(option => {
      option.checked =
        localStorage.getItem(option.dataset.columnName) === null
          ? true
          : localStorage.getItem(option.dataset.columnName) === 'true'
          ? true
          : false;

      setColumnVisibility(option.dataset.columnName, option.checked);
    });

  viewOptions && viewOptions.addEventListener('change', viewOptionChange);
})();
