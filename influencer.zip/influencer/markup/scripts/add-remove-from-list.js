(() => {
  // add to/remove from list
  const addToListButton = document.querySelector('.add-to-list');
  const removeFromListButton = document.querySelector('.remove-from-list');

  const showListMenu = evt => {
    evt.stopPropagation();
    evt.currentTarget.classList.toggle('active');

    document.addEventListener('click', hideListMenu);
  };

  const hideListMenu = evt => {
    addToListButton.classList.remove('active');
    removeFromListButton.classList.remove('active');

    document.removeEventListener('click', hideListMenu);
  };

  addToListButton && addToListButton.addEventListener('click', showListMenu);
  removeFromListButton && removeFromListButton.addEventListener('click', showListMenu);
})();
