(() => {
  // select avatar image
  const avatarFileName = document.querySelector('#avatar');
  const avatarPreview = document.querySelector('#avatar-preview');

  const FILE_TYPES = ['gif', 'jpg', 'jpeg', 'png'];

  const loadAvatar = fileName => {
    const onAvatarLoad = () => {
      URL.revokeObjectURL(avatarPreview.src);
      avatarPreview.removeEventListener('load', onAvatarLoad);
    };

    avatarPreview.addEventListener('load', onAvatarLoad);
    avatarPreview.src = URL.createObjectURL(fileName);
  };

  const fileChooser = (file, onCheckPassed) => {
    const fileName = file.name.toLowerCase();

    const matches = FILE_TYPES.some(function (it) {
      return fileName.endsWith(it);
    });

    if (matches) {
      onCheckPassed(file);
    }
  };

  const onAvatarFileNameChange = () => fileChooser(avatarFileName.files[0], loadAvatar);

  avatarFileName && avatarFileName.addEventListener('change', onAvatarFileNameChange);
})();
