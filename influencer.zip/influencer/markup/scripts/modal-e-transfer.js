(() => {
  // modal e-transfer
  const ANIMATION_DURATION = 500;
  let isETransferAdded = false;

  const modalETransfer = document.getElementById('modal-e-transfer');
  const buttonOpenETransferModal = document.getElementById('button-open-e-transfer');
  const modalETransferCloseButton =
    modalETransfer && document.getElementById('modal-e-transfer-close-button');
  const modalETransferAddButton =
    modalETransfer && document.getElementById('modal-e-transfer-add-button');

  const modalETransferName = document.getElementById('e-transfer-name');
  const modalETransferEmail = document.getElementById('e-transfer-email');

  const modalShow = () => {
    document.body.style.overflowY = 'hidden';
    modalETransfer.classList.add('modal--animate');
    setTimeout(() => modalETransfer.classList.add('modal--opened'), 0);
    setTimeout(() => modalETransfer.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const modalHide = evt => {
    if (
      evt.target !== modalETransfer &&
      evt.target !== modalETransferCloseButton &&
      evt.target !== modalETransferAddButton
    )
      return;

    if (!isETransferAdded) {
      modalETransferName.value = '';
      modalETransferEmail.value = '';
    }

    document.body.style.overflowY = 'auto';
    modalETransfer.classList.add('modal--animate');
    modalETransfer.classList.remove('modal--opened');
    setTimeout(() => modalETransfer.classList.remove('modal--animate'), ANIMATION_DURATION);
  };

  const onAddButtonClick = evt => {
    isETransferAdded = true;
    buttonOpenETransferModal.innerHTML = 'Edit';
    modalETransferAddButton.innerHTML = 'Edit E-Transfer Account';

    modalHide(evt);
  };

  buttonOpenETransferModal &&
    modalETransfer &&
    buttonOpenETransferModal.addEventListener('click', modalShow);
  modalETransfer && modalETransfer.addEventListener('click', modalHide);
  modalETransferCloseButton && modalETransferCloseButton.addEventListener('click', modalHide);
  modalETransferAddButton && modalETransferAddButton.addEventListener('click', onAddButtonClick);
})();
