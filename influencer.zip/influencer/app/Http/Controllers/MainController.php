<?php

namespace App\Http\Controllers;


class MainController extends Controller
{
    public function index()
    {
//      return view('client-dashboard');

        if(auth()->user()->profile_flag == 0)
        {
            return view('influencer.account-detail');
        }
        else {
            return view('influencer.home');
        }
    }
    public function done()
    {
       // Write all form fields (ie. $_POST['name']) to DB
        return view('influencer.home');
    }

}
