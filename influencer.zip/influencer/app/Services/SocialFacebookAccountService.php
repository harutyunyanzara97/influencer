<?php
namespace App\Services;
use App\Models\SocialFacebookAccount;
use App\Models\User;
use Illuminate\Support\Facades\Artisan;
use Laravel\Socialite\Contracts\User as ProviderUser;
use Laravel\Socialite\Facades\Socialite;

class SocialFacebookAccountService
{
    public function createOrGetUser(ProviderUser $providerUser)
    {

        $account = SocialFacebookAccount::whereProvider('facebook')
            ->whereProviderUserId($providerUser->getId())
            ->first();
        $social = Socialite::driver('facebook')->user();
        $avatar = $social->avatar_original . "&access_token={$social->token}";
        if ($account) {
            $account->user->avatar_url=$avatar;
            return $account->user;
        } else {
            $account = new SocialFacebookAccount([
                'provider_user_id' => $providerUser->getId(),
                'provider' => 'facebook'
            ]);
            $user = User::whereEmail($providerUser->getEmail())->first();
            $social = Socialite::driver('facebook')->user();
            $avatar = $social->avatar_original . "&access_token={$social->token}";
            if (!$user) {
                $user = User::create([
                    'email' => $providerUser->getEmail(),
                    'name' => $providerUser->getName(),
                    'password' => md5(rand(1,10000)),
                    'avatar_url' => $avatar,
                ]);
            }
            $account->user()->associate($user);
            $account->save();
            return $user;
        }

    }
}
