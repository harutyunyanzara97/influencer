<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTagNetworksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tag_networks', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable('false');
            $table->unsignedInteger('network_id')->nullable('false');
            $table->string('network_url')->nullable('false');
            $table->timestamps();
        });
        Schema::table('tag_networks', function($table) {
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');
            $table->foreign('network_id')->references('id')->on('networks')->onDelete('cascade')->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tag_networks');
    }
}
